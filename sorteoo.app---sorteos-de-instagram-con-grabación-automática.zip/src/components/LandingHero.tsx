import React from 'react';
import { Play, Sparkles, Video, ShieldCheck, Instagram, ArrowRight } from 'lucide-react';

interface LandingHeroProps {
  onStartGiveaway: (initialQuery?: string) => void;
  onExploreDemo: () => void;
}

export const LandingHero: React.FC<LandingHeroProps> = ({
  onStartGiveaway,
  onExploreDemo,
}) => {
  return (
    <section className="relative pt-8 pb-14 md:pt-16 md:pb-24 w-full max-w-full overflow-hidden">
      {/* Background radial atmosphere (bounded) */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-full max-w-[600px] h-[350px] bg-gradient-to-tr from-red-600/15 via-rose-600/10 to-amber-600/15 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10 w-full overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Column: Value Proposition & Main CTA (7 cols) */}
          <div className="lg:col-span-7 space-y-5 text-center lg:text-left">
            {/* Differential tag with logo colors */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-neutral-900/90 border border-rose-500/30 rounded-full text-xs font-semibold text-rose-300 shadow-sm">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Sorteos de Instagram certificados · 100% Gratis</span>
            </div>

            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-[1.15] text-balance">
              Haz tu sorteo de Instagram con{' '}
              <span className="bg-gradient-to-r from-red-500 via-rose-500 to-amber-500 bg-clip-text text-transparent">
                video automático
              </span>{' '}
              para Stories y Reels.
            </h1>

            <p className="text-sm sm:text-base text-neutral-300 max-w-2xl mx-auto lg:mx-0 leading-relaxed">
              Elige ganadores transparentes a partir de los comentarios reales de tus publicaciones o realiza sorteos por enlaces, listas o números. Descarga el video vertical 9:16 listo para compartir.
            </p>

            {/* Main Action Buttons (User Request: "El boton principal del inicio debe ser 'CREAR SORTEO'") */}
            <div className="pt-2 flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3.5">
              <button
                type="button"
                onClick={() => onStartGiveaway()}
                className="w-full sm:w-auto px-9 py-4 bg-gradient-to-r from-red-500 via-rose-500 to-amber-500 hover:from-red-600 hover:via-rose-600 hover:to-amber-600 text-white font-black text-sm sm:text-base rounded-2xl shadow-xl shadow-rose-500/25 transition-all transform active:scale-95 flex items-center justify-center gap-2.5 group"
              >
                <span>CREAR SORTEO</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                type="button"
                onClick={onExploreDemo}
                className="w-full sm:w-auto px-6 py-4 bg-neutral-900/90 hover:bg-neutral-800 text-neutral-200 border border-neutral-800 hover:border-neutral-700 font-bold text-xs sm:text-sm rounded-2xl transition-colors flex items-center justify-center gap-2"
              >
                <Play className="w-3.5 h-3.5 text-rose-400 fill-current" />
                <span>Ver demostración (@circusdanceclub)</span>
              </button>
            </div>

            {/* Perks badges */}
            <div className="pt-2 flex flex-wrap items-center justify-center lg:justify-start gap-4 text-xs text-neutral-400">
              <span className="flex items-center gap-1.5 text-emerald-400 font-semibold">
                <ShieldCheck className="w-4 h-4" /> Sin registro obligatorio
              </span>
              <span className="hidden sm:inline">·</span>
              <span className="flex items-center gap-1.5 text-neutral-300 font-medium">
                <Video className="w-4 h-4 text-rose-400" /> Video vertical 9:16
              </span>
              <span className="flex items-center gap-1.5 text-neutral-300 font-medium">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Verificador Oficial</span>
              </span>
            </div>

            {/* Key benefits metrics */}
            <div className="pt-6 border-t border-neutral-800/80 grid grid-cols-3 gap-3 text-neutral-400 max-w-lg mx-auto lg:mx-0 text-left">
              <div>
                <span className="block text-lg sm:text-xl font-bold text-white tabular-nums">9:16</span>
                <span className="text-[11px] text-neutral-400">Vertical Stories</span>
              </div>
              <div>
                <span className="block text-lg sm:text-xl font-bold text-white tabular-nums">0 clics</span>
                <span className="text-[11px] text-neutral-400">Grabación auto</span>
              </div>
              <div>
                <span className="block text-lg sm:text-xl font-bold text-white tabular-nums">100%</span>
                <span className="text-[11px] text-neutral-400">Transparente</span>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive 9:16 Showcase Card (5 cols) */}
          <div className="lg:col-span-5 flex justify-center w-full overflow-hidden">
            <div className="relative w-full max-w-[290px] sm:max-w-[340px] aspect-[9/16] bg-neutral-950 rounded-3xl p-3 shadow-2xl border-2 border-neutral-800/80 overflow-hidden group mx-auto">
              {/* Phone speaker / camera notch bar */}
              <div className="absolute top-4 left-1/2 -translate-x-1/2 w-28 h-4 bg-black rounded-full z-20 flex items-center justify-center">
                <div className="w-3 h-3 rounded-full bg-neutral-900 mr-2" />
                <div className="w-8 h-1 bg-neutral-800 rounded-full" />
              </div>

              {/* Inside screen container */}
              <div className="relative w-full h-full bg-gradient-to-b from-[#131127] to-[#0B0F19] rounded-2xl p-5 flex flex-col justify-between overflow-hidden border border-neutral-800">
                {/* Header */}
                <div className="pt-8 text-center">
                  <span className="text-[11px] font-bold tracking-widest text-rose-400 uppercase">
                    sorteoo.app
                  </span>
                  <h4 className="text-xs text-white/90 font-semibold mt-0.5">
                    @creator_official · Sorteo Oficial
                  </h4>
                </div>

                {/* Center Winner Animation Simulator */}
                <div className="my-auto space-y-4">
                  <div className="relative mx-auto w-24 h-24 rounded-full bg-gradient-to-tr from-amber-400 via-rose-500 to-indigo-500 p-1 shadow-2xl shadow-rose-500/30">
                    <div className="w-full h-full rounded-full bg-neutral-950 flex items-center justify-center text-3xl font-black text-amber-400">
                      S
                    </div>
                    {/* Glowing badge */}
                    <div className="absolute -bottom-1 -right-1 bg-emerald-500 text-white rounded-full p-1 shadow-md">
                      <ShieldCheck className="w-4 h-4" />
                    </div>
                  </div>

                  <div className="text-center">
                    <span className="text-[10px] font-extrabold text-amber-400 uppercase tracking-wider block">
                      ¡GANADORA OFICIAL!
                    </span>
                    <span className="text-xl font-black text-white block mt-0.5">
                      @sofia_martinez
                    </span>
                    <p className="text-[11px] text-neutral-300 italic mt-1 px-2 line-clamp-2">
                      “¡Ojalá ganar este sorteo increíble! @amigo1 @amigo2”
                    </p>
                  </div>

                  <div className="bg-white/5 border border-white/10 rounded-xl p-3 text-center">
                    <span className="text-[10px] text-neutral-400 block">
                      Certificado de Transparencia
                    </span>
                    <span className="text-xs font-mono font-bold text-white">
                      SRT-4B29-K1
                    </span>
                  </div>
                </div>

                {/* Footer simulation */}
                <div className="pb-2 text-center border-t border-white/10 pt-3">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-rose-500/20 text-rose-300 rounded-full text-[10px] font-bold">
                    <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping" />
                    Grabado en 9:16 para Reels
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
