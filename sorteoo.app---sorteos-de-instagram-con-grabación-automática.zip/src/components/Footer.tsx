import React from 'react';

interface FooterProps {
  onNavigate: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-neutral-950 border-t border-neutral-900 py-10 px-4 sm:px-6 w-full overflow-hidden">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="text-center md:text-left">
          <span className="text-lg font-black tracking-tight text-white flex items-center justify-center md:justify-start gap-1">
            <span className="bg-gradient-to-r from-red-500 via-rose-500 to-amber-500 bg-clip-text text-transparent">
              sorteoo
            </span>
            <span>.app</span>
          </span>
          <p className="text-xs text-neutral-500 mt-1">
            Sorteos certificados con grabación automática vertical 9:16 y Verificador oficial.
          </p>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-5 text-xs text-neutral-400">
          <button onClick={() => onNavigate('home')} className="hover:text-white transition-colors">
            Inicio
          </button>
          <button onClick={() => onNavigate('create')} className="hover:text-white transition-colors">
            Crear Sorteo
          </button>
          <button onClick={() => onNavigate('profile')} className="hover:text-white transition-colors">
            Mis Sorteos
          </button>
          <button onClick={() => onNavigate('verify')} className="hover:text-white transition-colors">
            Verificador
          </button>
          <span className="text-neutral-600">·</span>
          <span>© {new Date().getFullYear()} sorteoo.app</span>
        </div>
      </div>
    </footer>
  );
};
