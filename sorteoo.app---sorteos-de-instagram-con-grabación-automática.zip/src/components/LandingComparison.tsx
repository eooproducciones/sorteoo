import React from 'react';
import { Check, X, Shield, Video, Zap } from 'lucide-react';

export const LandingComparison: React.FC = () => {
  const comparisonRows = [
    {
      feature: 'Grabación de video del sorteo',
      sorteoo: 'Automática en formato vertical 9:16 nativo',
      traditional: 'Requiere grabar la pantalla manualmente',
    },
    {
      feature: 'Privacidad durante la grabación',
      sorteoo: 'Solo captura el escenario del sorteo (sin notificaciones privadas)',
      traditional: 'Expone notificaciones de WhatsApp y llamadas personales',
    },
    {
      feature: 'Persistencia del historial y videos',
      sorteoo: 'Guardado seguro en tu cuenta con acceso multidispositivo',
      traditional: 'Se pierde al cerrar la pestaña o recargar',
    },
    {
      feature: 'Certificado de transparencia',
      sorteoo: 'Firma criptográfica SHA-256 + Verificador público oficial',
      traditional: 'Captura estática sin mecanismo de verificación',
    },
    {
      feature: 'Exportación a Instagram Stories / Reels',
      sorteoo: 'Directa vía Web Share API o descarga en 1080×1920',
      traditional: 'Requiere recortar y editar el video a mano',
    },
  ];

  return (
    <section className="py-14 sm:py-20 bg-neutral-950 border-t border-neutral-900 w-full overflow-hidden">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 w-full">
        <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-16">
          <span className="text-xs font-bold tracking-widest text-emerald-400 uppercase">
            Comparativa
          </span>
          <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight mt-2">
            ¿Por qué elegir sorteoo.app?
          </h2>
          <p className="mt-2 text-xs sm:text-sm text-neutral-400">
            Diseñamos sorteoo.app pensando en los problemas reales a los que se enfrentan los creadores de contenido cada semana.
          </p>
        </div>

        {/* Comparison Table with overflow protection */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-2xl overflow-hidden shadow-2xl w-full">
          <div className="grid grid-cols-12 bg-neutral-950 p-3.5 sm:p-6 border-b border-neutral-800 text-xs font-bold text-neutral-300">
            <div className="col-span-5 sm:col-span-4">Característica</div>
            <div className="col-span-7 sm:col-span-4 text-rose-400 flex items-center gap-1.5">
              <Zap className="w-4 h-4 fill-current" />
              <span>sorteoo.app</span>
            </div>
            <div className="hidden sm:block sm:col-span-4 text-neutral-500">
              Otras plataformas tradicionales
            </div>
          </div>

          <div className="divide-y divide-neutral-800/70">
            {comparisonRows.map((row, idx) => (
              <div
                key={idx}
                className="grid grid-cols-12 p-4 sm:p-6 text-xs items-center hover:bg-neutral-800/30 transition-colors"
              >
                <div className="col-span-5 sm:col-span-4 font-semibold text-white">
                  {row.feature}
                </div>
                <div className="col-span-7 sm:col-span-4 text-emerald-300 flex items-start gap-2">
                  <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{row.sorteoo}</span>
                </div>
                <div className="col-span-12 sm:col-span-4 text-neutral-400 flex items-start gap-2 mt-2 sm:mt-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-neutral-800">
                  <X className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                  <span>{row.traditional}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
