import React, { useState } from 'react';
import { Participant, GiveawayFilters, PostDetails, InstagramProfile, InstagramProfilePost } from '../types/giveaway';
import { api } from '../services/api';
import { filterParticipants } from '../utils/giveawayLogic';
import {
  AtSign,
  Link as LinkIcon,
  Filter,
  Trophy,
  Users,
  CheckCircle2,
  AlertCircle,
  FileSpreadsheet,
  ArrowRight,
  ArrowLeft,
  Settings2,
  Upload,
  Info,
  Play,
  Plus,
  Trash2,
  Grid,
  Heart,
  MessageCircle,
  Sparkles,
  Search,
  Check,
  Hash,
  FileText,
  ExternalLink,
  ShieldCheck,
  RefreshCw,
  ChevronDown,
  X
} from 'lucide-react';

interface CreateGiveawayWizardProps {
  initialQuery?: string;
  onStartGiveaway: (config: {
    postUrl: string;
    postDetails: PostDetails;
    participants: Participant[];
    filters: GiveawayFilters;
    winnersCount: number;
    substitutesCount: number;
  }) => void;
  onCancel: () => void;
}

export const CreateGiveawayWizard: React.FC<CreateGiveawayWizardProps> = ({
  initialQuery,
  onStartGiveaway,
  onCancel,
}) => {
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  // Active Giveaway Mode: 'username' | 'link' | 'list' | 'numbers' | 'csv'
  const [activeSource, setActiveSource] = useState<'username' | 'link' | 'list' | 'numbers' | 'csv'>('username');

  // Option 1: Instagram Username & Wall
  const [targetUsername, setTargetUsername] = useState(
    initialQuery && !initialQuery.includes('instagram.com') ? initialQuery.trim().replace(/^@/, '') : ''
  );
  const [profileData, setProfileData] = useState<InstagramProfile | null>(null);
  const [loadingProfile, setLoadingProfile] = useState(false);
  const [selectedPost, setSelectedPost] = useState<InstagramProfilePost | null>(null);
  const [postToSelectModal, setPostToSelectModal] = useState<InstagramProfilePost | null>(null);
  const [directPostUrlInput, setDirectPostUrlInput] = useState('');
  const [postSearchFilter, setPostSearchFilter] = useState('');
  const [failedImages, setFailedImages] = useState<Record<string, boolean>>({});
  const [visiblePostsCount, setVisiblePostsCount] = useState<number>(6);
  const [loadingMorePosts, setLoadingMorePosts] = useState<boolean>(false);

  // Option 2: Direct URL
  const [directUrl, setDirectUrl] = useState(
    initialQuery && initialQuery.includes('instagram.com') ? initialQuery.trim() : 'https://www.instagram.com/p/DAxK79qO3b/'
  );

  // Option 3: Manual text list
  const [manualListText, setManualListText] = useState('');

  // Option 4: Number Range (e.g. 1 to 1000)
  const [numMin, setNumMin] = useState<number>(1);
  const [numMax, setNumMax] = useState<number>(1000);

  // Option 5: CSV File
  const [csvContent, setCsvContent] = useState('');

  // Shared parsing states
  const [loadingComments, setLoadingComments] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [postDetails, setPostDetails] = useState<PostDetails | null>(null);
  const [rawParticipants, setRawParticipants] = useState<Participant[]>([]);
  const [sourceType, setSourceType] = useState<'instagram' | 'numbers' | 'csv' | 'list'>('instagram');

  // Step 2: Filters (Duplicates default to FALSE, empty excluded users)
  const [filters, setFilters] = useState<GiveawayFilters>({
    minMentions: 0,
    removeDuplicateUsers: false,
    requiredKeyword: '',
    excludedUsers: [],
  });
  const [newExcludedItem, setNewExcludedItem] = useState('');

  // Step 3: Sliders for Winners (up to 50) and Substitutes (up to 10)
  const [winnersCount, setWinnersCount] = useState<number>(1);
  const [substitutesCount, setSubstitutesCount] = useState<number>(2);

  // Auto-search if initialQuery was provided from Landing
  React.useEffect(() => {
    if (initialQuery && initialQuery.trim().length > 0) {
      const q = initialQuery.trim();
      if (q.includes('instagram.com/')) {
        setDirectUrl(q);
        setActiveSource('link');
        const autoFetch = async () => {
          setLoadingComments(true);
          setErrorMsg(null);
          try {
            const data = await api.parseInstagramPost(q, false);
            setPostDetails({
              ...data.postDetails,
              sourceType: 'instagram',
            });
            setRawParticipants(data.participants || []);
            setSourceType('instagram');
            setStep(2);
          } catch (err: any) {
            setErrorMsg(err.message || 'No se pudo obtener el post de Instagram');
          } finally {
            setLoadingComments(false);
          }
        };
        autoFetch();
      } else {
        const userClean = q.replace(/^@/, '');
        setTargetUsername(userClean);
        setActiveSource('username');
        const autoSearch = async () => {
          setLoadingProfile(true);
          setErrorMsg(null);
          setSelectedPost(null);
          try {
            const res = await api.getInstagramProfileFeed(userClean);
            setProfileData(res.profile);
            if (res.profile?.posts?.length > 0) {
              setSelectedPost(res.profile.posts[0]);
            }
          } catch (err: any) {
            setErrorMsg(err.message || 'No se pudo obtener el perfil de Instagram');
          } finally {
            setLoadingProfile(false);
          }
        };
        autoSearch();
      }
    }
  }, [initialQuery]);

  // Search Instagram Profile & Open Wall
  const handleSearchProfileWall = async (overrideUser?: string) => {
    setErrorMsg(null);
    const userClean = (overrideUser || targetUsername).trim().replace(/^@/, '');
    if (!userClean) {
      setErrorMsg('Por favor escribe el nombre de usuario de Instagram');
      return;
    }
    setLoadingProfile(true);
    setSelectedPost(null);
    setPostToSelectModal(null);
    setFailedImages({});
    setVisiblePostsCount(6);
    try {
      const res = await api.getInstagramProfileFeed(userClean);
      setProfileData(res.profile);
      if (res.profile?.posts?.length > 0) {
        setSelectedPost(res.profile.posts[0]);
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Error al obtener el perfil de Instagram');
    } finally {
      setLoadingProfile(false);
    }
  };

  // Load more posts: reveals next 6 from current batch or fetches older posts from Instagram
  const handleLoadMorePosts = async () => {
    if (!profileData) return;
    const currentTotal = profileData.posts?.length || 0;

    // If there are already loaded posts in memory beyond the current 6, reveal them first
    if (visiblePostsCount < currentTotal) {
      setVisiblePostsCount((prev) => Math.min(prev + 6, currentTotal));
      return;
    }

    // Otherwise, if Instagram returned a pagination token, fetch older posts
    if (profileData.paginationToken) {
      setLoadingMorePosts(true);
      try {
        const res = await api.getInstagramProfileFeed(profileData.username, profileData.paginationToken);
        const newPosts: InstagramProfilePost[] = res.profile?.posts || [];
        if (newPosts.length > 0) {
          const existingCodes = new Set(profileData.posts.map((p) => p.shortcode));
          const filteredNew = newPosts.filter((p) => !existingCodes.has(p.shortcode));
          const merged = [...profileData.posts, ...filteredNew];
          setProfileData({
            ...profileData,
            posts: merged,
            paginationToken: res.profile?.paginationToken || null,
          });
          setVisiblePostsCount((prev) => prev + (filteredNew.length > 0 ? Math.min(6, filteredNew.length) : 0));
        } else {
          setProfileData({
            ...profileData,
            paginationToken: null,
          });
        }
      } catch (err: any) {
        console.warn('Error al cargar publicaciones más antiguas:', err);
      } finally {
        setLoadingMorePosts(false);
      }
    }
  };

  // Confirm selected post from Instagram wall and advance directly to Step 2 (never return to selection)
  const handleConfirmWallPost = async (postToConfirm?: InstagramProfilePost) => {
    const target = postToConfirm || selectedPost;
    if (!target || !profileData) {
      setErrorMsg('Por favor selecciona la publicación que deseas sortear');
      return;
    }
    setErrorMsg(null);
    setSelectedPost(target);
    setPostToSelectModal(null);
    setStep(2); // IMMEDIATELY jump to Step 2 so user never returns to selection!
    setLoadingComments(true);
    try {
      const data = await api.parseInstagramPost(
        target.postUrl,
        false,
        profileData.username,
        target.caption,
        target.commentsCount
      );
      setPostDetails({
        ...data.postDetails,
        imageUrl: target.imageUrl || data.postDetails.imageUrl,
        sourceType: 'instagram',
      });
      setRawParticipants(data.participants || []);
      setSourceType('instagram');
    } catch (err: any) {
      setErrorMsg(err.message || 'Error al cargar los comentarios de la publicación');
    } finally {
      setLoadingComments(false);
    }
  };

  // Confirm direct post URL in Wall modal
  const handleConfirmDirectPostUrlInWall = async () => {
    if (!directPostUrlInput.trim()) {
      setErrorMsg('Por favor ingresa la URL de la publicación');
      return;
    }
    setErrorMsg(null);
    setLoadingComments(true);
    try {
      const author = profileData?.username || 'instagram_creator';
      const data = await api.parseInstagramPost(directPostUrlInput.trim(), false, author);
      setPostDetails({
        ...data.postDetails,
        author: author !== 'instagram_creator' ? author : data.postDetails.author,
        sourceType: 'instagram',
      });
      setRawParticipants(data.participants || []);
      setSourceType('instagram');
      setStep(2);
    } catch (err: any) {
      setErrorMsg(err.message || 'URL de publicación inválida');
    } finally {
      setLoadingComments(false);
    }
  };

  // Direct Link
  const handleConfirmDirectLink = async () => {
    setErrorMsg(null);
    if (!directUrl.trim()) {
      setErrorMsg('Por favor ingresa la URL de la publicación o reel de Instagram');
      return;
    }
    setLoadingComments(true);
    try {
      const data = await api.parseInstagramPost(directUrl.trim(), false);
      setPostDetails({
        ...data.postDetails,
        sourceType: 'instagram',
      });
      setRawParticipants(data.participants || []);
      setSourceType('instagram');
      setStep(2);
    } catch (err: any) {
      setErrorMsg(err.message || 'Error al conectar con la publicación de Instagram');
    } finally {
      setLoadingComments(false);
    }
  };

  // Number range generator
  const handleGenerateNumbers = () => {
    setErrorMsg(null);
    if (numMax <= numMin) {
      setErrorMsg('El número final debe ser mayor al número inicial');
      return;
    }
    const count = numMax - numMin + 1;
    if (count > 20000) {
      setErrorMsg('El rango no puede superar los 20,000 números');
      return;
    }

    const participants: Participant[] = [];
    for (let i = numMin; i <= numMax; i++) {
      participants.push({
        username: `#${i}`,
        comment: `Boleto o número participante #${i}`,
        avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=num_${i}`,
        timestamp: new Date().toISOString(),
      });
    }

    setPostDetails({
      shortcode: `num_${numMin}_to_${numMax}`,
      author: 'sorteo_por_numeros',
      likes: count,
      commentsCount: count,
      caption: `Sorteo por números del #${numMin} al #${numMax}`,
      imageUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=600&auto=format&fit=crop&q=80',
      sourceType: 'numbers',
    });

    setRawParticipants(participants);
    setSourceType('numbers');
    setFilters({
      minMentions: 0,
      removeDuplicateUsers: true,
      requiredKeyword: '',
      excludedUsers: [],
    });
    setStep(2);
  };

  // Manual text or CSV list processing
  const handleProcessTextList = (text: string, type: 'csv' | 'list') => {
    setErrorMsg(null);
    const content = text.trim();
    if (!content) {
      setErrorMsg('Por favor escribe o pega la lista de participantes');
      return;
    }

    const lines = content.split(/[\r\n]+/).map((l) => l.trim()).filter((l) => l.length > 0);
    if (lines.length === 0) {
      setErrorMsg('No se detectaron participantes válidos');
      return;
    }

    const isPureNumbers = lines.every((l) => /^[#]?\d+$/.test(l.replace(/,/g, '').trim()));
    const participants: Participant[] = [];

    lines.forEach((line, idx) => {
      let username = '';
      let comment = '';

      if (isPureNumbers) {
        const clean = line.replace(/,/g, '').trim();
        username = clean.startsWith('#') ? clean : `#${clean}`;
        comment = `Boleto participante ${username}`;
      } else if (line.includes(',')) {
        const parts = line.split(',');
        username = parts[0].trim().replace(/^@/, '');
        comment = parts.slice(1).join(',').trim() || `Participante ${idx + 1}`;
      } else {
        username = line.trim().replace(/^@/, '');
        comment = `Participante registrado: ${line.trim()}`;
      }

      participants.push({
        username,
        comment,
        avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(username)}`,
        timestamp: new Date().toISOString(),
      });
    });

    setPostDetails({
      shortcode: isPureNumbers ? 'sorteo_numeros' : 'lista_participantes',
      author: isPureNumbers ? 'sorteo_por_numeros' : 'lista_personalizada',
      likes: participants.length,
      commentsCount: participants.length,
      caption: isPureNumbers
        ? `Sorteo entre ${participants.length} números`
        : `Sorteo entre ${participants.length} participantes`,
      imageUrl: 'https://images.unsplash.com/photo-1513151233558-d860c5398176?w=600&auto=format&fit=crop&q=80',
      sourceType: isPureNumbers ? 'numbers' : type,
    });

    setRawParticipants(participants);
    setSourceType(isPureNumbers ? 'numbers' : type);
    if (isPureNumbers) {
      setFilters({ minMentions: 0, removeDuplicateUsers: true, requiredKeyword: '', excludedUsers: [] });
    }
    setStep(2);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      setCsvContent(text);
      handleProcessTextList(text, 'csv');
    };
    reader.readAsText(file);
  };

  // Add excluded user/number
  const handleAddExcludedItem = () => {
    if (!newExcludedItem.trim()) return;
    const clean = newExcludedItem.trim().replace(/^@/, '');
    if (!filters.excludedUsers.includes(clean)) {
      setFilters({
        ...filters,
        excludedUsers: [...filters.excludedUsers, clean],
      });
    }
    setNewExcludedItem('');
  };

  const handleRemoveExcludedItem = (item: string) => {
    setFilters({
      ...filters,
      excludedUsers: filters.excludedUsers.filter((u) => u !== item),
    });
  };

  // Compute live filter results
  const filterResults = filterParticipants(rawParticipants, filters);

  const handleStart = () => {
    const totalRequired = winnersCount + substitutesCount;
    if (filterResults.validParticipants.length < totalRequired) {
      setErrorMsg(
        `Participantes válidos insuficientes (${filterResults.validParticipants.length}). Se necesitan al menos ${totalRequired} (${winnersCount} ganadores + ${substitutesCount} suplentes).`
      );
      return;
    }

    if (!postDetails) return;

    onStartGiveaway({
      postUrl: postDetails.shortcode ? `https://www.instagram.com/p/${postDetails.shortcode}/` : 'https://sorteoo.app',
      postDetails,
      participants: filterResults.validParticipants,
      filters,
      winnersCount,
      substitutesCount,
    });
  };

  // Filter profile posts in wall search (limited to visiblePostsCount: initially 6)
  const filteredPosts = (profileData?.posts || []).filter((p) => {
    if (!postSearchFilter.trim()) return true;
    const term = postSearchFilter.toLowerCase();
    return (p.caption || '').toLowerCase().includes(term) || (p.shortcode || '').toLowerCase().includes(term);
  });
  const visiblePosts = filteredPosts.slice(0, visiblePostsCount);

  return (
    <div className="w-full max-w-4xl mx-auto px-3 sm:px-6 py-4 sm:py-8 overflow-x-hidden">
      {/* Top Header & Breadcrumb Progress */}
      <div className="mb-5 sm:mb-6">
        <div className="flex items-center justify-between gap-2 mb-2.5">
          <button
            type="button"
            onClick={onCancel}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-neutral-400 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Volver al inicio</span>
          </button>
          <span className="text-xs font-bold bg-neutral-900 border border-neutral-800 text-neutral-300 px-3 py-0.5 rounded-full">
            Paso {step} de 4
          </span>
        </div>

        {/* 4 Step Progress Pills */}
        <div className="grid grid-cols-4 gap-1.5 sm:gap-2">
          {[
            { num: 1, label: 'Tipo de sorteo' },
            { num: 2, label: 'Filtros' },
            { num: 3, label: 'Ganadores' },
            { num: 4, label: 'Confirmación' },
          ].map((s) => (
            <div
              key={s.num}
              className={`h-1.5 rounded-full transition-all ${
                step >= s.num ? 'bg-gradient-to-r from-red-500 via-rose-500 to-amber-500' : 'bg-neutral-800'
              }`}
            />
          ))}
        </div>
      </div>

      {errorMsg && (
        <div className="mb-5 p-3.5 bg-rose-500/10 border border-rose-500/30 rounded-2xl flex items-start gap-3 text-rose-300 text-xs">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* ==================================================== */}
      {/* STEP 1: MINIMALIST & CLEAN GIVEAWAY SETUP            */}
      {/* ==================================================== */}
      {step === 1 && (
        <div className="space-y-4 sm:space-y-5">
          {/* Minimalist Single Title (User request: "En el paso 1 basta con solo poner el titulo, como deseas realizar tu sorteo") */}
          <h1 className="text-xl sm:text-2xl font-black text-white text-center sm:text-left">
            ¿Cómo deseas realizar tu sorteo?
          </h1>

          {/* Unified Giveaway Mode Selector Tabs */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 p-1.5 bg-neutral-900/90 border border-neutral-800 rounded-2xl">
            {/* Mode 1: Por Usuario */}
            <button
              type="button"
              onClick={() => setActiveSource('username')}
              className={`col-span-2 sm:col-span-1 p-2.5 sm:p-3 rounded-xl text-left transition-all flex flex-col justify-between ${
                activeSource === 'username'
                  ? 'bg-gradient-to-b from-red-500/15 via-rose-500/10 to-amber-500/10 border-2 border-rose-500 shadow-md text-white'
                  : 'hover:bg-neutral-800/60 text-neutral-400 hover:text-white border border-transparent'
              }`}
            >
              <div className="flex items-center justify-between gap-1 mb-1">
                <div className="w-6 h-6 rounded-lg bg-gradient-to-tr from-red-500 via-rose-500 to-amber-500 flex items-center justify-center text-white shrink-0 shadow-sm">
                  <AtSign className="w-3.5 h-3.5" />
                </div>
                <span className="text-[9px] font-black uppercase tracking-wider bg-rose-500/20 text-rose-300 px-1.5 py-0.5 rounded">
                  Recomendado
                </span>
              </div>
              <div>
                <span className="text-xs font-bold block text-white">Por Usuario</span>
                <span className="text-[10px] text-neutral-400 block line-clamp-1">Muro de Instagram</span>
              </div>
            </button>

            {/* Mode 2: Por Enlace */}
            <button
              type="button"
              onClick={() => setActiveSource('link')}
              className={`p-2.5 sm:p-3 rounded-xl text-left transition-all flex flex-col justify-between ${
                activeSource === 'link'
                  ? 'bg-neutral-800 border-2 border-rose-500/80 shadow-md text-white'
                  : 'hover:bg-neutral-800/60 text-neutral-400 hover:text-white border border-transparent'
              }`}
            >
              <div className="w-6 h-6 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center mb-1 shrink-0">
                <LinkIcon className="w-3.5 h-3.5" />
              </div>
              <div>
                <span className="text-xs font-bold block text-white">Por Enlace</span>
                <span className="text-[10px] text-neutral-400 block line-clamp-1">URL de Post / Reel</span>
              </div>
            </button>

            {/* Mode 3: Lista de nombres */}
            <button
              type="button"
              onClick={() => setActiveSource('list')}
              className={`p-2.5 sm:p-3 rounded-xl text-left transition-all flex flex-col justify-between ${
                activeSource === 'list'
                  ? 'bg-neutral-800 border-2 border-rose-500/80 shadow-md text-white'
                  : 'hover:bg-neutral-800/60 text-neutral-400 hover:text-white border border-transparent'
              }`}
            >
              <div className="w-6 h-6 rounded-lg bg-pink-500/20 text-pink-400 flex items-center justify-center mb-1 shrink-0">
                <FileText className="w-3.5 h-3.5" />
              </div>
              <div>
                <span className="text-xs font-bold block text-white">Lista Nombres</span>
                <span className="text-[10px] text-neutral-400 block line-clamp-1">Pegar participantes</span>
              </div>
            </button>

            {/* Mode 4: Por Números */}
            <button
              type="button"
              onClick={() => setActiveSource('numbers')}
              className={`p-2.5 sm:p-3 rounded-xl text-left transition-all flex flex-col justify-between ${
                activeSource === 'numbers'
                  ? 'bg-neutral-800 border-2 border-rose-500/80 shadow-md text-white'
                  : 'hover:bg-neutral-800/60 text-neutral-400 hover:text-white border border-transparent'
              }`}
            >
              <div className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center mb-1 shrink-0">
                <Hash className="w-3.5 h-3.5" />
              </div>
              <div>
                <span className="text-xs font-bold block text-white">Por Números</span>
                <span className="text-[10px] text-neutral-400 block line-clamp-1">Rifas del 1 al N</span>
              </div>
            </button>

            {/* Mode 5: Archivo CSV */}
            <button
              type="button"
              onClick={() => setActiveSource('csv')}
              className={`p-2.5 sm:p-3 rounded-xl text-left transition-all flex flex-col justify-between ${
                activeSource === 'csv'
                  ? 'bg-neutral-800 border-2 border-rose-500/80 shadow-md text-white'
                  : 'hover:bg-neutral-800/60 text-neutral-400 hover:text-white border border-transparent'
              }`}
            >
              <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center mb-1 shrink-0">
                <FileSpreadsheet className="w-3.5 h-3.5" />
              </div>
              <div>
                <span className="text-xs font-bold block text-white">Archivo CSV</span>
                <span className="text-[10px] text-neutral-400 block line-clamp-1">Importar archivo</span>
              </div>
            </button>
          </div>

          {/* ========================================= */}
          {/* 1. INSTAGRAM BY USERNAME (DIRECT & CLEAN) */}
          {/* ========================================= */}
          {activeSource === 'username' && (
            <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-4 sm:p-6 shadow-xl space-y-4">
              {/* Direct Input Field (User request: "En la opcion de por usuario directamente poner el cuadro para que ingrese el usuario... en el cuadro pone '@ ingresa usuario de instagram'") */}
              <div className="flex flex-col sm:flex-row gap-2.5">
                <div className="relative flex-1">
                  <input
                    type="text"
                    value={targetUsername}
                    onChange={(e) => setTargetUsername(e.target.value.replace(/^@/, ''))}
                    placeholder="@ ingresa usuario de instagram"
                    className="w-full px-4 py-3 bg-neutral-950 border border-neutral-700 focus:border-rose-500 rounded-xl text-white text-[16px] sm:text-sm font-semibold focus:outline-none transition-all shadow-inner placeholder-neutral-500"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleSearchProfileWall();
                      }
                    }}
                  />
                </div>

                <button
                  type="button"
                  onClick={() => handleSearchProfileWall()}
                  disabled={loadingProfile}
                  className="px-6 py-3 bg-gradient-to-r from-red-500 via-rose-500 to-amber-500 hover:from-red-600 hover:via-rose-600 hover:to-amber-600 disabled:opacity-50 text-white text-xs sm:text-sm font-extrabold rounded-xl shadow-lg shadow-rose-500/20 transition-all flex items-center justify-center gap-2 shrink-0 active:scale-95"
                >
                  {loadingProfile ? (
                    <span className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 animate-spin text-amber-300" />
                      <span>Buscando posts...</span>
                    </span>
                  ) : (
                    <>
                      <Grid className="w-4 h-4" />
                      <span>BUSCAR PUBLICACIONES</span>
                    </>
                  )}
                </button>
              </div>

              {/* Loading State */}
              {loadingProfile && (
                <div className="p-6 bg-neutral-950/80 rounded-2xl border border-rose-500/30 text-center space-y-2">
                  <div className="w-10 h-10 mx-auto rounded-xl bg-gradient-to-tr from-red-500 via-rose-500 to-amber-500 p-0.5 shadow-xl animate-bounce">
                    <div className="w-full h-full rounded-xl bg-neutral-950 flex items-center justify-center text-lg">
                      🎁
                    </div>
                  </div>
                  <h3 className="text-xs sm:text-sm font-extrabold text-white">
                    Cargando muro de @{targetUsername || 'tu cuenta'}...
                  </h3>
                </div>
              )}

              {/* Profile Details & Posts Wall */}
              {profileData && !loadingProfile && (
                <div className="space-y-4 pt-2 border-t border-neutral-800">
                  {/* Account Header Badge */}
                  <div className="bg-neutral-950/90 p-3 sm:p-4 rounded-2xl border border-neutral-800 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <img
                        src={profileData.avatar}
                        alt={profileData.username}
                        referrerPolicy="no-referrer"
                        className="w-10 h-10 rounded-full border border-neutral-700 object-cover shrink-0"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = `https://api.dicebear.com/7.x/bottts/svg?seed=${profileData.username}`;
                        }}
                      />
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-extrabold text-white text-xs sm:text-sm">@{profileData.username}</span>
                          {profileData.isPrivate ? (
                            <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-full font-bold">
                              Privada 🔒
                            </span>
                          ) : (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          )}
                        </div>
                        <p className="text-[11px] text-neutral-400 truncate">
                          {profileData.followersCount > 0
                            ? `${profileData.followersCount.toLocaleString()} seguidores · ${profileData.postsCount} posts`
                            : `@${profileData.username}`}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleSearchProfileWall()}
                      className="inline-flex items-center gap-1 text-[11px] text-neutral-400 hover:text-white px-2.5 py-1.5 rounded-lg bg-neutral-900 border border-neutral-800 transition-colors shrink-0"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span className="hidden sm:inline">Actualizar</span>
                    </button>
                  </div>

                  {/* POSTS GRID */}
                  {profileData.posts && profileData.posts.length > 0 && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-bold text-white flex items-center gap-1.5">
                          <Grid className="w-3.5 h-3.5 text-rose-400" />
                          <span>Elige una publicación ({profileData.posts.length}):</span>
                        </span>

                        {/* Search filter for posts */}
                        <div className="relative w-44 sm:w-56">
                          <Search className="w-3 h-3 absolute left-2.5 top-1/2 -translate-y-1/2 text-neutral-500" />
                          <input
                            type="text"
                            value={postSearchFilter}
                            onChange={(e) => setPostSearchFilter(e.target.value)}
                            placeholder="Filtrar posts..."
                            className="w-full pl-7 pr-2.5 py-1 bg-neutral-950 border border-neutral-800 rounded-lg text-[16px] sm:text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-rose-500"
                          />
                        </div>
                      </div>

                      {/* Post cards grid */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                        {visiblePosts.map((post, idx) => {
                          const isSelected = selectedPost?.shortcode === post.shortcode;
                          const hasImgFailed = failedImages[post.shortcode];

                          return (
                            <div
                              key={post.shortcode || idx}
                              onClick={() => {
                                setSelectedPost(post);
                                setPostToSelectModal(post); // Trigger immediate selection popup!
                              }}
                              className={`group relative rounded-2xl overflow-hidden border-2 cursor-pointer transition-all flex flex-col justify-between ${
                                isSelected
                                  ? 'border-rose-500 ring-4 ring-rose-500/25 bg-neutral-900 shadow-xl'
                                  : 'border-neutral-800 hover:border-neutral-700 bg-neutral-950 hover:bg-neutral-900/60'
                              }`}
                            >
                              {/* Media Thumbnail Container */}
                              <div className="relative aspect-square w-full bg-neutral-950 overflow-hidden">
                                {!hasImgFailed && post.imageUrl ? (
                                  <img
                                    src={post.imageUrl}
                                    alt={`Post ${post.shortcode}`}
                                    referrerPolicy="no-referrer"
                                    crossOrigin="anonymous"
                                    loading="lazy"
                                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                    onError={() => {
                                      setFailedImages((prev) => ({ ...prev, [post.shortcode]: true }));
                                    }}
                                  />
                                ) : (
                                  <div className="w-full h-full bg-gradient-to-tr from-neutral-950 via-neutral-900 to-neutral-950 p-4 flex flex-col justify-between border-b border-neutral-850">
                                    <div className="flex items-center justify-between">
                                      <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-red-500 via-rose-500 to-amber-500 flex items-center justify-center text-white">
                                        <Sparkles className="w-3.5 h-3.5" />
                                      </div>
                                      <span className="text-[10px] font-mono text-neutral-400 bg-neutral-800 px-1.5 py-0.5 rounded">
                                        {post.shortcode}
                                      </span>
                                    </div>
                                    <p className="text-xs text-neutral-200 line-clamp-3 italic">
                                      “{post.caption || 'Publicación oficial de Instagram'}”
                                    </p>
                                    <span className="text-[10px] text-neutral-500 block font-semibold">
                                      @{profileData.username}
                                    </span>
                                  </div>
                                )}

                                {/* Overlay Badges */}
                                <div className="absolute top-2 left-2 flex items-center gap-1 z-10">
                                  {post.isGiveaway && (
                                    <span className="bg-gradient-to-r from-red-500 to-amber-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded-md shadow-md">
                                      SORTEO 🎁
                                    </span>
                                  )}
                                  <span className="bg-black/75 backdrop-blur-md text-white text-[9px] font-bold px-1.5 py-0.5 rounded-md border border-white/10">
                                    {post.isVideo ? 'Reel 🎬' : 'Post 📷'}
                                  </span>
                                </div>

                                {/* Checkmark when selected */}
                                {isSelected && (
                                  <div className="absolute top-2 right-2 bg-gradient-to-tr from-red-500 to-amber-500 text-white rounded-full p-1.5 shadow-xl z-10">
                                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                                  </div>
                                )}

                                {/* Bottom Stat Bar */}
                                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent p-2.5 pt-6 flex items-center justify-between text-[11px] font-bold text-white">
                                  <span className="flex items-center gap-1 bg-black/60 px-2 py-0.5 rounded-md border border-white/10">
                                    <MessageCircle className="w-3 h-3 text-rose-400 fill-current" />
                                    <span>{post.commentsCount}</span>
                                  </span>
                                  <span className="flex items-center gap-1 text-neutral-300">
                                    <Heart className="w-3 h-3 text-rose-400" />
                                    <span>{post.likes}</span>
                                  </span>
                                </div>
                              </div>

                              {/* Card Content & Text Details */}
                              <div className="p-2.5 space-y-1.5 flex-1 flex flex-col justify-between">
                                <p className="text-xs text-neutral-200 line-clamp-2 leading-tight">
                                  {post.caption || `Publicación de @${profileData.username}`}
                                </p>

                                <div className="pt-1.5 border-t border-neutral-850 flex items-center justify-between text-[10px] text-neutral-400">
                                  <span>{post.date}</span>
                                  <span className="text-rose-400 font-bold group-hover:underline flex items-center gap-0.5">
                                    <span>Tocar para elegir</span>
                                    <ArrowRight className="w-3 h-3" />
                                  </span>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>

                      {/* Load More Posts Button (User request: "tienen que aparecer solo 6 y si queremos cargar mas publicaciones para que se vean que tenga la opcion de 'cargar mas'") */}
                      {(visiblePostsCount < filteredPosts.length || profileData.paginationToken) && (
                        <div className="pt-3 text-center">
                          <button
                            type="button"
                            onClick={handleLoadMorePosts}
                            disabled={loadingMorePosts}
                            className="inline-flex items-center gap-2 px-6 py-3 bg-neutral-900 hover:bg-neutral-850 text-white text-xs sm:text-sm font-black rounded-2xl border border-neutral-700 hover:border-neutral-600 transition-all shadow-lg active:scale-95 cursor-pointer disabled:opacity-50"
                          >
                            {loadingMorePosts ? (
                              <>
                                <RefreshCw className="w-4 h-4 animate-spin text-rose-400" />
                                <span>Cargando más publicaciones de Instagram...</span>
                              </>
                            ) : (
                              <>
                                <ChevronDown className="w-4 h-4 text-rose-400" />
                                <span>
                                  Cargar más publicaciones
                                  {filteredPosts.length > visiblePostsCount
                                    ? ` (${filteredPosts.length - visiblePostsCount} restantes)`
                                    : ''}
                                </span>
                              </>
                            )}
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* 2. DIRECT LINK */}
          {activeSource === 'link' && (
            <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-4 sm:p-6 shadow-xl space-y-4">
              <input
                type="url"
                value={directUrl}
                onChange={(e) => setDirectUrl(e.target.value)}
                placeholder="https://www.instagram.com/p/..."
                className="w-full px-4 py-3 bg-neutral-950 border border-neutral-700 focus:border-rose-500 rounded-xl text-white text-[16px] sm:text-sm font-mono focus:outline-none"
              />
              <button
                type="button"
                onClick={handleConfirmDirectLink}
                disabled={loadingComments}
                className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-red-500 via-rose-500 to-amber-500 hover:from-red-600 hover:to-amber-600 text-white text-xs sm:text-sm font-extrabold rounded-xl shadow-lg transition-all flex items-center justify-center gap-2"
              >
                {loadingComments ? <span>Cargando comentarios...</span> : <span>Cargar comentarios</span>}
              </button>
            </div>
          )}

          {/* 3. PARTICIPANTS LIST */}
          {activeSource === 'list' && (
            <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-4 sm:p-6 shadow-xl space-y-4">
              <textarea
                rows={5}
                value={manualListText}
                onChange={(e) => setManualListText(e.target.value)}
                placeholder={`Sofia Martinez\nLucas Valenzuela\nCamila Gomez\n...o @usuario, comentario`}
                className="w-full p-3 bg-neutral-950 border border-neutral-800 focus:border-rose-500 rounded-xl text-white text-[16px] sm:text-xs font-mono focus:outline-none"
              />
              <button
                type="button"
                onClick={() => handleProcessTextList(manualListText, 'list')}
                className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-red-500 via-rose-500 to-amber-500 hover:from-red-600 hover:to-amber-600 text-white text-xs sm:text-sm font-extrabold rounded-xl shadow-lg transition-all flex items-center justify-center gap-2"
              >
                <span>Procesar lista de participantes</span>
              </button>
            </div>
          )}

          {/* 4. NUMBER RANGE */}
          {activeSource === 'numbers' && (
            <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-4 sm:p-6 shadow-xl space-y-4">
              <div className="grid grid-cols-2 gap-3 max-w-xs">
                <div>
                  <label className="block text-[11px] font-semibold text-neutral-400 mb-1">Desde</label>
                  <input
                    type="number"
                    value={numMin}
                    onChange={(e) => setNumMin(parseInt(e.target.value, 10) || 1)}
                    className="w-full px-3 py-2 bg-neutral-950 border border-neutral-700 rounded-xl text-white text-[16px] sm:text-xs font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-neutral-400 mb-1">Hasta</label>
                  <input
                    type="number"
                    value={numMax}
                    onChange={(e) => setNumMax(parseInt(e.target.value, 10) || 100)}
                    className="w-full px-3 py-2 bg-neutral-950 border border-neutral-700 rounded-xl text-white text-[16px] sm:text-xs font-mono font-bold"
                  />
                </div>
              </div>
              <button
                type="button"
                onClick={handleGenerateNumbers}
                className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-red-500 via-rose-500 to-amber-500 hover:from-red-600 hover:to-amber-600 text-white text-xs sm:text-sm font-extrabold rounded-xl shadow-lg transition-all flex items-center justify-center gap-2"
              >
                <span>Generar {numMax - numMin + 1} boletos</span>
              </button>
            </div>
          )}

          {/* 5. CSV FILE */}
          {activeSource === 'csv' && (
            <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-4 sm:p-6 shadow-xl space-y-4 text-center">
              <label className="cursor-pointer inline-flex items-center gap-2 px-5 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold rounded-xl border border-neutral-700 transition-colors">
                <Upload className="w-4 h-4 text-emerald-400" />
                <span>Elegir archivo .csv o .txt</span>
                <input type="file" accept=".csv,.txt" onChange={handleFileUpload} className="hidden" />
              </label>
            </div>
          )}

          {/* ⭐ POPUP MODAL WHEN USER CLICKS A POST (User request: "si ya selecciono una publicacion tiene que salirme un popup con el boton 'Seleccionar este post' y pasar al siguiente paso") */}
          {postToSelectModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-150">
              <div className="bg-neutral-900 border-2 border-rose-500/50 rounded-3xl p-5 sm:p-6 w-full max-w-sm sm:max-w-md shadow-2xl relative space-y-4 animate-in zoom-in-95 duration-150">
                {/* Close Button */}
                <button
                  type="button"
                  onClick={() => setPostToSelectModal(null)}
                  className="absolute top-4 right-4 p-1.5 rounded-full bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
                  aria-label="Cerrar ventana"
                >
                  <X className="w-4 h-4" />
                </button>

                <div className="flex items-start gap-3.5 pr-6">
                  {/* Thumbnail */}
                  <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-neutral-950 overflow-hidden shrink-0 border border-neutral-800">
                    {postToSelectModal.imageUrl ? (
                      <img
                        src={postToSelectModal.imageUrl}
                        alt="Preview"
                        referrerPolicy="no-referrer"
                        crossOrigin="anonymous"
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = `https://api.dicebear.com/7.x/bottts/svg?seed=${postToSelectModal.shortcode}`;
                        }}
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-xl">
                        🎁
                      </div>
                    )}
                  </div>

                  <div className="min-w-0 flex-1 space-y-1">
                    <span className="text-[10px] font-black uppercase tracking-wider text-rose-400 block">
                      Publicación lista para sortear
                    </span>
                    <strong className="text-white text-sm sm:text-base block truncate">
                      💬 {postToSelectModal.commentsCount} comentarios
                    </strong>
                    <p className="text-xs text-neutral-300 line-clamp-2 leading-tight">
                      {postToSelectModal.caption || `Publicación de @${profileData?.username}`}
                    </p>
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      const p = postToSelectModal;
                      setPostToSelectModal(null);
                      if (p) {
                        handleConfirmWallPost(p);
                      }
                    }}
                    className="w-full py-4 bg-gradient-to-r from-red-500 via-rose-500 to-amber-500 hover:from-red-600 hover:via-rose-600 hover:to-amber-600 text-white font-black text-sm sm:text-base rounded-2xl shadow-xl shadow-rose-500/30 transition-all flex items-center justify-center gap-2 transform active:scale-95 cursor-pointer"
                  >
                    <span>Seleccionar este post</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ==================================================== */}
      {/* STEP 2: FILTERS & CONDITIONS */}
      {/* ==================================================== */}
      {step === 2 && (
        <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-5 sm:p-7 space-y-5">
          <div className="border-b border-neutral-800 pb-3 flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-rose-400 uppercase tracking-wider block mb-0.5">
                Paso 2
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                Filtros del Sorteo
              </h2>
            </div>
            {selectedPost && (
              <span className="text-xs font-bold text-neutral-400 bg-neutral-950 border border-neutral-800 px-3 py-1 rounded-xl">
                @{profileData?.username || postDetails?.author || 'instagram'}
              </span>
            )}
          </div>

          {/* Loading Comments State inside Step 2 */}
          {loadingComments ? (
            <div className="py-12 px-4 bg-neutral-950 rounded-2xl border border-rose-500/30 text-center space-y-4">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-tr from-red-500 via-rose-500 to-amber-500 p-0.5 shadow-xl animate-pulse">
                <div className="w-full h-full rounded-2xl bg-neutral-950 flex items-center justify-center text-2xl">
                  🎁
                </div>
              </div>
              <div className="space-y-1">
                <h3 className="text-base sm:text-lg font-black text-white">
                  Cargando todos los comentarios de Instagram...
                </h3>
                <p className="text-xs sm:text-sm text-neutral-400 max-w-md mx-auto">
                  Estamos recopilando todos los comentarios reales de la publicación para preparar el sorteo. Por favor espera unos segundos.
                </p>
              </div>
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-neutral-900 rounded-xl border border-neutral-800 text-xs font-bold text-rose-400">
                <Sparkles className="w-4 h-4 animate-spin text-amber-300" />
                <span>Extrayendo participantes reales...</span>
              </div>
            </div>
          ) : (
            <>
              {/* Summary of Total Participants Loaded */}
              <div className="bg-neutral-950 p-3.5 sm:p-4 rounded-2xl border border-neutral-800 flex items-center justify-between">
                <div>
                  <span className="text-xs text-neutral-400 block">Comentarios detectados</span>
                  <strong className="text-sm sm:text-base font-bold text-white">
                    {rawParticipants.length}
                  </strong>
                </div>
                <div className="text-right">
                  <span className="text-xs text-neutral-400 block">Válidos para sortear</span>
                  <strong className="text-sm sm:text-base font-black text-emerald-400">
                    {filterResults.validParticipants.length}
                  </strong>
                </div>
              </div>

              <div className="space-y-3.5">
                {/* Filter 1: Duplicates (User request: destildada por default) */}
                <div className="flex items-center justify-between p-3.5 sm:p-4 bg-neutral-950 rounded-2xl border border-neutral-800">
                  <div>
                    <h4 className="text-xs sm:text-sm font-bold text-white">
                      Eliminar comentarios duplicados
                    </h4>
                    <p className="text-[11px] text-neutral-400">
                      {filters.removeDuplicateUsers
                        ? '1 oportunidad por usuario'
                        : 'Permite múltiples comentarios'}
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={filters.removeDuplicateUsers}
                    onChange={(e) => setFilters({ ...filters, removeDuplicateUsers: e.target.checked })}
                    className="w-5 h-5 accent-rose-500 rounded cursor-pointer"
                  />
                </div>

                {/* Filter 2: Mentions (User request: cambiar titulo por "Tiene que mencionar?" y poner "Sin menciones" / "Con menciones") */}
                {sourceType === 'instagram' && (
                  <div className="p-3.5 sm:p-4 bg-neutral-950 rounded-2xl border border-neutral-800 space-y-2.5">
                    <div>
                      <h4 className="text-xs sm:text-sm font-bold text-white">
                        Tiene que mencionar?
                      </h4>
                      <p className="text-[11px] text-neutral-400">
                        Condición de menciones a amigos en los comentarios
                      </p>
                    </div>
                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => setFilters({ ...filters, minMentions: 0 })}
                        className={`py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold border transition-all cursor-pointer ${
                          filters.minMentions === 0
                            ? 'bg-rose-500 border-rose-500 text-white shadow-md'
                            : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white'
                        }`}
                      >
                        Sin menciones
                      </button>
                      <button
                        type="button"
                        onClick={() => setFilters({ ...filters, minMentions: filters.minMentions > 0 ? filters.minMentions : 1 })}
                        className={`py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold border transition-all cursor-pointer ${
                          filters.minMentions > 0
                            ? 'bg-rose-500 border-rose-500 text-white shadow-md'
                            : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white'
                        }`}
                      >
                        Con menciones
                      </button>
                    </div>
                  </div>
                )}

                {/* Filter 3: Required Keyword (User request: sacale el "(opcional)") */}
                <div className="p-3.5 sm:p-4 bg-neutral-950 rounded-2xl border border-neutral-800 space-y-1.5">
                  <h4 className="text-xs sm:text-sm font-bold text-white">
                    Palabra clave o hashtag
                  </h4>
                  <input
                    type="text"
                    value={filters.requiredKeyword}
                    onChange={(e) => setFilters({ ...filters, requiredKeyword: e.target.value })}
                    placeholder="ej: #sorteo o QUIEROGANAR"
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-xl text-white text-[16px] sm:text-xs focus:outline-none focus:border-rose-500"
                  />
                </div>

                {/* Filter 4: Excluded users (User request: sacale los ejemplos de @bot_account y @spam_user) */}
                <div className="p-3.5 sm:p-4 bg-neutral-950 rounded-2xl border border-neutral-800 space-y-2">
                  <h4 className="text-xs sm:text-sm font-bold text-white">
                    Excluir usuarios
                  </h4>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={newExcludedItem}
                      onChange={(e) => setNewExcludedItem(e.target.value)}
                      placeholder="@usuario"
                      className="flex-1 px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-xl text-white text-[16px] sm:text-xs focus:outline-none"
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleAddExcludedItem();
                        }
                      }}
                    />
                    <button
                      type="button"
                      onClick={handleAddExcludedItem}
                      className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold rounded-xl cursor-pointer"
                    >
                      Excluir
                    </button>
                  </div>

                  {filters.excludedUsers.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {filters.excludedUsers.map((item) => (
                        <span
                          key={item}
                          className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-neutral-850 text-neutral-300 rounded-lg text-xs"
                        >
                          <span>@{item}</span>
                          <button
                            type="button"
                            onClick={() => handleRemoveExcludedItem(item)}
                            className="text-neutral-500 hover:text-rose-400"
                          >
                            ×
                          </button>
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-neutral-800">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-neutral-400 hover:text-white cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Atrás</span>
                </button>
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="flex items-center gap-2 px-6 py-2.5 bg-gradient-to-r from-red-500 via-rose-500 to-amber-500 hover:from-red-600 hover:via-rose-600 hover:to-amber-600 text-white text-xs sm:text-sm font-extrabold rounded-xl shadow-lg transition-all active:scale-95 cursor-pointer"
                >
                  <span>Elegir ganadores</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </>
          )}
        </div>
      )}

      {/* ==================================================== */}
      {/* STEP 3: NUMBER OF WINNERS & SUBSTITUTES */}
      {/* ==================================================== */}
      {step === 3 && (
        <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-5 sm:p-7 space-y-5">
          <div className="border-b border-neutral-800 pb-3">
            <span className="text-xs font-bold text-rose-400 uppercase tracking-wider block mb-0.5">
              Paso 3
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              Ganadores y Suplentes
            </h2>
          </div>

          {/* Winners Slider */}
          <div className="p-4 sm:p-5 bg-neutral-950 rounded-2xl border border-neutral-800 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-bold text-white">Cantidad de Ganadores</h4>
                <p className="text-xs text-neutral-400">Premios oficiales a sortear</p>
              </div>
              <div className="px-3.5 py-1 bg-gradient-to-r from-red-500 via-rose-500 to-amber-500 text-white rounded-xl text-base font-black">
                {winnersCount}
              </div>
            </div>

            <input
              type="range"
              min={1}
              max={Math.min(50, Math.max(1, filterResults.validParticipants.length))}
              value={winnersCount}
              onChange={(e) => setWinnersCount(parseInt(e.target.value, 10))}
              className="w-full h-2.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-rose-500"
            />
          </div>

          {/* Substitutes Slider */}
          <div className="p-4 sm:p-5 bg-neutral-950 rounded-2xl border border-neutral-800 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-bold text-white">Cantidad de Suplentes</h4>
                <p className="text-xs text-neutral-400">De reserva si el ganador no responde</p>
              </div>
              <div className="px-3.5 py-1 bg-neutral-800 text-neutral-200 rounded-xl text-base font-black">
                {substitutesCount}
              </div>
            </div>

            <input
              type="range"
              min={0}
              max={10}
              value={substitutesCount}
              onChange={(e) => setSubstitutesCount(parseInt(e.target.value, 10))}
              className="w-full h-2.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
            />
          </div>

          <div className="flex items-center justify-between pt-3 border-t border-neutral-800">
            <button
              type="button"
              onClick={() => setStep(2)}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-neutral-400 hover:text-white"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Atrás</span>
            </button>
            <button
              type="button"
              onClick={() => setStep(4)}
              className="flex items-center gap-2 px-6 py-2.5 bg-gradient-to-r from-red-500 via-rose-500 to-amber-500 hover:from-red-600 hover:to-amber-600 text-white text-xs sm:text-sm font-extrabold rounded-xl shadow-lg transition-all active:scale-95"
            >
              <span>Revisar y sortear</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* STEP 4: CONFIRMATION & LIVE DRAW LAUNCH */}
      {/* ==================================================== */}
      {step === 4 && (
        <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-5 sm:p-7 space-y-5">
          <div className="border-b border-neutral-800 pb-3">
            <span className="text-xs font-bold text-rose-400 uppercase tracking-wider block mb-0.5">
              Paso 4
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              Confirmación del Sorteo
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="bg-neutral-950 p-3.5 rounded-2xl border border-neutral-800 space-y-1">
              <span className="text-neutral-400 block font-medium">Publicación / Origen</span>
              <p className="font-bold text-white truncate text-sm">
                {sourceType === 'numbers' ? 'Sorteo por Números' : `@${postDetails?.author || 'instagram_user'}`}
              </p>
              <p className="text-neutral-400 text-[11px] truncate">{postDetails?.caption}</p>
            </div>

            <div className="bg-neutral-950 p-3.5 rounded-2xl border border-neutral-800 space-y-1">
              <span className="text-neutral-400 block font-medium">Participantes Válidos</span>
              <p className="font-extrabold text-emerald-400 text-base">
                {filterResults.validParticipants.length} participantes
              </p>
            </div>

            <div className="bg-neutral-950 p-3.5 rounded-2xl border border-neutral-800 space-y-1">
              <span className="text-neutral-400 block font-medium">Ganadores</span>
              <p className="font-bold text-amber-400 text-sm">
                {winnersCount} Ganador{winnersCount > 1 ? 'es' : ''} {substitutesCount > 0 ? `+ ${substitutesCount} Suplente(s)` : ''}
              </p>
            </div>

            <div className="bg-neutral-950 p-3.5 rounded-2xl border border-neutral-800 space-y-1">
              <span className="text-neutral-400 block font-medium">Verificador & Video</span>
              <p className="font-bold text-rose-400 flex items-center gap-1.5 text-sm">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Verificador + Video 9:16</span>
              </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-neutral-800">
            <button
              type="button"
              onClick={() => setStep(3)}
              className="w-full sm:w-auto flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-neutral-400 hover:text-white"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Atrás</span>
            </button>
            <button
              type="button"
              onClick={handleStart}
              className="w-full sm:w-auto min-w-[280px] sm:min-w-[340px] flex items-center justify-center gap-3 py-5 px-8 sm:px-12 bg-gradient-to-r from-red-500 via-rose-500 to-amber-500 hover:from-red-600 hover:via-rose-600 hover:to-amber-600 text-white text-base sm:text-lg font-black rounded-full shadow-2xl shadow-rose-500/40 ring-4 ring-rose-500/30 hover:ring-rose-400/60 transition-all transform hover:scale-105 active:scale-95 cursor-pointer uppercase tracking-wider animate-pulse"
            >
              <Play className="w-6 h-6 fill-current text-white shrink-0" />
              <span>COMENZAR SORTEOO</span>
              <Sparkles className="w-5 h-5 text-amber-200 shrink-0" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
