import React from 'react';
import { LinkIcon, Sliders, Play, Download } from 'lucide-react';

export const LandingHowItWorks: React.FC = () => {
  const steps = [
    {
      num: '01',
      icon: <LinkIcon className="w-5 h-5 text-rose-400" />,
      title: 'Pega el enlace de Instagram',
      description:
        'Introduce el link de tu post o reel. También puedes cargar una lista en CSV o pegar comentarios manualmente si lo prefieres.',
    },
    {
      num: '02',
      icon: <Sliders className="w-5 h-5 text-indigo-400" />,
      title: 'Configura tus filtros y cupos',
      description:
        'Selecciona la cantidad de ganadores, suplentes de reserva, menciones mínimas (@amigos) y elimina participantes duplicados.',
    },
    {
      num: '03',
      icon: <Play className="w-5 h-5 text-amber-400" />,
      title: 'Haz clic en Sortear',
      description:
        'La ruleta visual inicia y la grabación en 9:16 se activa automáticamente en paralelo sin necesidad de capturadoras de pantalla.',
    },
    {
      num: '04',
      icon: <Download className="w-5 h-5 text-emerald-400" />,
      title: 'Descarga y publica tu video',
      description:
        'Recibe tu archivo vertical de alta definición listo para Stories y Reels, además de un certificado criptográfico de transparencia.',
    },
  ];

  return (
    <section id="how-it-works" className="py-20 bg-[#0B0F19]">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-xs font-bold tracking-widest text-indigo-400 uppercase">
            Paso a paso
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mt-2">
            Cómo funciona sorteoo.app
          </h2>
          <p className="mt-3 text-sm text-neutral-400">
            Un flujo simplificado en 4 pasos para que puedas realizar sorteos profesionales en menos de 2 minutos.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((s, idx) => (
            <div
              key={idx}
              className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 relative flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-6">
                  <div className="w-10 h-10 rounded-xl bg-neutral-800 flex items-center justify-center">
                    {s.icon}
                  </div>
                  <span className="font-mono text-2xl font-black text-neutral-700">
                    {s.num}
                  </span>
                </div>
                <h3 className="text-sm font-bold text-white mb-2">{s.title}</h3>
                <p className="text-xs text-neutral-400 leading-relaxed">{s.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
