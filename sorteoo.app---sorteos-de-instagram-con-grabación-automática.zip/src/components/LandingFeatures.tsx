import React from 'react';
import {
  Video,
  ShieldCheck,
  Filter,
  Instagram,
  Database,
  Smartphone,
  Sliders,
  CheckCircle2,
  Lock
} from 'lucide-react';

export const LandingFeatures: React.FC = () => {
  const features = [
    {
      icon: <Video className="w-6 h-6 text-rose-400" />,
      title: 'Grabación Automática 9:16',
      description:
        'Al hacer clic en Sortear, la plataforma graba la animación completa en resolución vertical de 1080×1920. Sin botones adicionales ni software externo.',
    },
    {
      icon: <ShieldCheck className="w-6 h-6 text-emerald-400" />,
      title: 'Verificador Criptográfico Real',
      description:
        'Selección con PRNG seguro Web Crypto, generación de código único y hash SHA-256 inmutable. Los resultados son fijos y verificables por cualquier usuario.',
    },
    {
      icon: <Filter className="w-6 h-6 text-indigo-400" />,
      title: 'Filtros Profesionales de Comentarios',
      description:
        'Exige menciones mínimas (@amigos), elimina usuarios duplicados para dar 1 chance por persona, o filtra por palabras clave y hashtags.',
    },
    {
      icon: <Instagram className="w-6 h-6 text-pink-400" />,
      title: 'Listo para Stories y Reels',
      description:
        'Descarga el archivo de video vertical o compártelo al instante a través de Web Share API en iOS y Android sin marcas de agua molestas.',
    },
    {
      icon: <Database className="w-6 h-6 text-amber-400" />,
      title: 'Historial y Videos en la Nube',
      description:
        'Cada sorteo se almacena en tu cuenta personal. Consulta certificados, ganadores y descarga nuevamente tus videos desde cualquier navegador.',
    },
    {
      icon: <Sliders className="w-6 h-6 text-cyan-400" />,
      title: 'Ganadores Múltiples y Suplentes',
      description:
        'Asigna hasta 10 ganadores en un solo sorteo y configura suplentes de reserva en orden prioritario para máxima transparencia.',
    },
  ];

  return (
    <section className="py-20 bg-neutral-950 border-t border-neutral-900">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-xs font-bold tracking-widest text-rose-400 uppercase">
            Ventajas competitivas
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mt-2">
            La plataforma definitiva para creadores y marcas
          </h2>
          <p className="mt-3 text-sm text-neutral-400">
            Diseñada para ofrecer entretenimiento visual, fiabilidad técnica absoluta y máxima comodidad para compartir en redes sociales.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feat, idx) => (
            <div
              key={idx}
              className="bg-neutral-900/60 border border-neutral-800 hover:border-neutral-700 rounded-2xl p-6 transition-all hover:shadow-xl group"
            >
              <div className="w-12 h-12 rounded-xl bg-neutral-800 flex items-center justify-center mb-5 group-hover:scale-105 transition-transform">
                {feat.icon}
              </div>
              <h3 className="text-base font-bold text-white mb-2">{feat.title}</h3>
              <p className="text-xs text-neutral-400 leading-relaxed">{feat.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
