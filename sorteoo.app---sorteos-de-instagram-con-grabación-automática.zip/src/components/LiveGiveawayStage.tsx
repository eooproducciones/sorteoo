import React, { useEffect, useRef, useState } from 'react';
import { Participant, GiveawayAudit } from '../types/giveaway';
import { CheckCircle2, AlertCircle } from 'lucide-react';

interface LiveGiveawayStageProps {
  postDetails: {
    shortcode: string;
    author: string;
    caption: string;
  };
  participants: Participant[];
  winners: Participant[];
  substitutes: Participant[];
  audit: GiveawayAudit;
  onFinish: (result: {
    videoBlob: Blob | null;
    videoDataUrl: string | null;
    durationSeconds: number;
    mimeType: string;
    recordingError?: string;
  }) => void;
  onCancel?: () => void;
}

interface ConfettiParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  rotation: number;
  vRot: number;
  shape: 'rect' | 'circle' | 'star';
}

export const LiveGiveawayStage: React.FC<LiveGiveawayStageProps> = ({
  postDetails,
  participants,
  winners,
  substitutes,
  audit,
  onFinish,
  onCancel,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [phase, setPhase] = useState<'starting' | 'countdown' | 'rolling' | 'revealing' | 'celebrating' | 'finalizing'>('starting');
  const [statusMessage, setStatusMessage] = useState<string>('Iniciando sorteo y grabación automática...');
  const [countdownNum, setCountdownNum] = useState<number>(3);
  const [recordingActive, setRecordingActive] = useState<boolean>(true);
  const [recordingError, setRecordingError] = useState<string | null>(null);

  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const animationFrameRef = useRef<number | null>(null);
  const startTimeRef = useRef<number>(0);

  // Preload avatars / placeholders to ensure canvas renders them instantly
  const avatarCache = useRef<Map<string, HTMLImageElement>>(new Map());

  // Canvas Resolution: Standard 9:16 vertical (1080 x 1920)
  const CANVAS_WIDTH = 1080;
  const CANVAS_HEIGHT = 1920;

  useEffect(() => {
    // Preload top participant avatars
    const toPreload = [...winners, ...substitutes, ...participants.slice(0, 15)];
    toPreload.forEach((p) => {
      if (p.avatarUrl && !avatarCache.current.has(p.username)) {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.src = p.avatarUrl;
        img.onload = () => avatarCache.current.set(p.username, img);
      }
    });
  }, [winners, substitutes, participants]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Set internal resolution
    canvas.width = CANVAS_WIDTH;
    canvas.height = CANVAS_HEIGHT;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Determine supported mimeType
    const mimeTypes = [
      'video/webm;codecs=vp9',
      'video/webm;codecs=vp8',
      'video/webm',
      'video/mp4',
    ];
    let selectedMimeType = '';
    for (const type of mimeTypes) {
      if (typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported(type)) {
        selectedMimeType = type;
        break;
      }
    }

    let recorder: MediaRecorder | null = null;
    try {
      if (typeof canvas.captureStream === 'function' && typeof MediaRecorder !== 'undefined') {
        const stream = canvas.captureStream(60); // 60 FPS capture
        recorder = new MediaRecorder(stream, selectedMimeType ? { mimeType: selectedMimeType } : undefined);
        recorderRef.current = recorder;
        chunksRef.current = [];

        recorder.ondataavailable = (e) => {
          if (e.data && e.data.size > 0) {
            chunksRef.current.push(e.data);
          }
        };

        // Automatic start on mount
        recorder.start(100);
        setRecordingActive(true);
      } else {
        setRecordingError('El navegador no admite captura directa por MediaRecorder. El sorteo continuará y los resultados se guardarán con certificado.');
        setRecordingActive(false);
      }
    } catch (err: any) {
      console.warn('Error starting recorder:', err);
      setRecordingError('No se pudo inicializar la grabación de video. Se continuará con el sorteo.');
      setRecordingActive(false);
    }

    // Animation timeline variables
    startTimeRef.current = performance.now();
    let currentPhase: 'countdown' | 'rolling' | 'revealing' | 'celebrating' | 'done' = 'countdown';
    let phaseStartTime = performance.now();

    // Confetti particles pool
    const confetti: ConfettiParticle[] = [];
    const colors = ['#FF4B72', '#7E3AF2', '#3B82F6', '#10B981', '#F59E0B', '#EC4899', '#FFFFFF'];

    function createConfettiBurst(count: number, yOrigin = 700) {
      for (let i = 0; i < count; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = Math.random() * 18 + 8;
        confetti.push({
          x: CANVAS_WIDTH / 2 + (Math.random() - 0.5) * 300,
          y: yOrigin,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed - 12,
          size: Math.random() * 16 + 8,
          color: colors[Math.floor(Math.random() * colors.length)],
          rotation: Math.random() * Math.PI * 2,
          vRot: (Math.random() - 0.5) * 0.2,
          shape: Math.random() > 0.4 ? 'rect' : 'circle',
        });
      }
    }

    // Render loop
    let rollingIndex = 0;
    let revealProgress = 0;
    let countdownVal = 3;

    const render = (now: number) => {
      const elapsed = now - startTimeRef.current;
      const phaseElapsed = now - phaseStartTime;

      // 1. Clear & draw background gradient
      const bgGrad = ctx.createLinearGradient(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
      bgGrad.addColorStop(0, '#0B0F19');
      bgGrad.addColorStop(0.4, '#131127');
      bgGrad.addColorStop(0.8, '#180B22');
      bgGrad.addColorStop(1, '#0B0F19');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

      // Ambient glow circles in background
      const ambientGlow = ctx.createRadialGradient(CANVAS_WIDTH / 2, 700, 50, CANVAS_WIDTH / 2, 700, 600);
      ambientGlow.addColorStop(0, 'rgba(236, 72, 153, 0.12)');
      ambientGlow.addColorStop(0.5, 'rgba(126, 58, 242, 0.08)');
      ambientGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = ambientGlow;
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

      // Safe area visual header (Inside standard Instagram Stories/Reels Safe Margin: top 180px)
      ctx.save();
      // App logo & verified badge
      ctx.fillStyle = '#FFFFFF';
      ctx.font = '800 52px "Plus Jakarta Sans", sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('sorteoo.app', CANVAS_WIDTH / 2, 230);

      ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
      ctx.font = '500 28px "Plus Jakarta Sans", sans-serif';
      const headerSubtitle =
        postDetails.author === 'sorteo_por_numeros'
          ? 'Sorteo Oficial por Números'
          : `@${(postDetails.author || 'instagram').replace(/^@/, '')} · Sorteo Oficial`;
      ctx.fillText(headerSubtitle, CANVAS_WIDTH / 2, 280);

      // Subtle separator line
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(CANVAS_WIDTH / 2 - 200, 315);
      ctx.lineTo(CANVAS_WIDTH / 2 + 200, 315);
      ctx.stroke();
      ctx.restore();

      // State Machine logic
      if (currentPhase === 'countdown') {
        const cdDuration = 2700; // 2.7 seconds total (0.9s per number)
        if (phaseElapsed < cdDuration) {
          const step = Math.floor(phaseElapsed / 900);
          countdownVal = 3 - step;
          setCountdownNum(countdownVal);
          setStatusMessage(`Iniciando en ${countdownVal}...`);

          // Draw animated countdown
          const subElapsed = (phaseElapsed % 900) / 900;
          const scale = 1 + (1 - subElapsed) * 0.4;
          const alpha = 1 - subElapsed * 0.3;

          ctx.save();
          ctx.translate(CANVAS_WIDTH / 2, 850);
          ctx.scale(scale, scale);

          // Glowing circle around number
          ctx.beginPath();
          ctx.arc(0, 0, 160, 0, Math.PI * 2);
          ctx.strokeStyle = `rgba(255, 75, 114, ${alpha})`;
          ctx.lineWidth = 10;
          ctx.stroke();

          ctx.fillStyle = `rgba(255, 255, 255, ${alpha})`;
          ctx.font = '800 180px "Plus Jakarta Sans", sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(`${countdownVal}`, 0, 0);

          ctx.restore();

          // Subtitle
          ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
          ctx.font = '600 36px "Plus Jakarta Sans", sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText('¡SORTEANDO GANADORES!', CANVAS_WIDTH / 2, 1100);
        } else {
          currentPhase = 'rolling';
          phaseStartTime = now;
          setPhase('rolling');
          setStatusMessage('Girando la ruleta de participantes...');
        }
      } else if (currentPhase === 'rolling') {
        const rollDuration = 3600; // 3.6s roulette
        if (phaseElapsed < rollDuration) {
          const progress = phaseElapsed / rollDuration;
          // Ease-out deceleration
          const speed = Math.max(1, Math.floor((1 - progress * 0.8) * 12));
          if (Math.floor(phaseElapsed / 50) % 2 === 0) {
            rollingIndex = (rollingIndex + 1) % participants.length;
          }

          const currentCandidate = participants[rollingIndex] || participants[0];

          // Draw Roulette Stage Box
          const boxY = 620;
          const boxH = 480;
          const boxW = 840;
          const boxX = (CANVAS_WIDTH - boxW) / 2;

          // Box container
          ctx.save();
          ctx.fillStyle = 'rgba(255, 255, 255, 0.05)';
          ctx.strokeStyle = 'rgba(255, 75, 114, 0.4)';
          ctx.lineWidth = 3;
          roundRect(ctx, boxX, boxY, boxW, boxH, 32);
          ctx.fill();
          ctx.stroke();

          // Roulette indicator badge
          ctx.fillStyle = 'rgba(255, 75, 114, 0.9)';
          roundRect(ctx, CANVAS_WIDTH / 2 - 130, boxY - 26, 260, 52, 26);
          ctx.fill();
          ctx.fillStyle = '#FFFFFF';
          ctx.font = '700 24px "Plus Jakarta Sans", sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText('SELECCIONANDO', CANVAS_WIDTH / 2, boxY + 8);

          // Candidate avatar (fallback circle or image)
          const avatarSize = 130;
          const avatarY = boxY + 140;
          ctx.beginPath();
          ctx.arc(CANVAS_WIDTH / 2, avatarY, avatarSize / 2, 0, Math.PI * 2);
          ctx.fillStyle = '#7E3AF2';
          ctx.fill();
          ctx.strokeStyle = '#FFFFFF';
          ctx.lineWidth = 4;
          ctx.stroke();

          // Draw initial if no avatar
          ctx.fillStyle = '#FFFFFF';
          ctx.font = '800 52px "Plus Jakarta Sans", sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          const initial = (currentCandidate.username || 'A')[0].toUpperCase();
          ctx.fillText(initial, CANVAS_WIDTH / 2, avatarY);

          // Candidate username or ticket number
          const candidateLabel =
            currentCandidate.username.startsWith('#') || currentCandidate.username.startsWith('Número') || currentCandidate.username.includes(' ')
              ? currentCandidate.username
              : `@${currentCandidate.username.replace(/^@/, '')}`;

          ctx.fillStyle = '#FFFFFF';
          ctx.font = '800 48px "Plus Jakarta Sans", sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'alphabetic';
          ctx.fillText(candidateLabel, CANVAS_WIDTH / 2, boxY + 280);

          // Candidate comment snippet
          ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
          ctx.font = '400 28px "Plus Jakarta Sans", sans-serif';
          const truncatedComment =
            currentCandidate.comment.length > 55
              ? currentCandidate.comment.substring(0, 52) + '...'
              : currentCandidate.comment;
          ctx.fillText(`"${truncatedComment}"`, CANVAS_WIDTH / 2, boxY + 340);

          // Participants scanned counter
          ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
          ctx.font = '500 24px "JetBrains Mono", monospace';
          ctx.fillText(
            `Participantes en juego: ${participants.length} · Algoritmo PRNG`,
            CANVAS_WIDTH / 2,
            boxY + 410
          );

          ctx.restore();
        } else {
          currentPhase = 'revealing';
          phaseStartTime = now;
          setPhase('revealing');
          setStatusMessage('¡Revelando ganadores oficiales!');
          createConfettiBurst(120, 600);
        }
      } else if (currentPhase === 'revealing' || currentPhase === 'celebrating') {
        // Winner & Substitutes Reveal Stage
        const revealDuration = 1200;
        revealProgress = Math.min(1, phaseElapsed / revealDuration);

        // All Winners Reveal Stage (Equal numbered winners: Ganador 1, Ganador 2...)
        const totalWinners = winners.length;

        // Header celebration banner
        ctx.save();
        ctx.fillStyle = '#F59E0B';
        ctx.font = '800 44px "Plus Jakarta Sans", sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(
          totalWinners > 1 ? `👑 ¡${totalWinners} GANADORES OFICIALES! 👑` : '👑 ¡GANADOR OFICIAL! 👑',
          CANVAS_WIDTH / 2,
          410
        );

        ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
        ctx.font = '600 24px "Plus Jakarta Sans", sans-serif';
        ctx.fillText('Seleccionados mediante algoritmo PRNG verificado', CANVAS_WIDTH / 2, 450);
        ctx.restore();

        // Helper to format handle / number / name
        const formatName = (u: string) => {
          if (!u) return '';
          if (u.startsWith('Número') || u.startsWith('#') || u.includes(' ')) return u;
          return `@${u.replace(/^@/, '')}`;
        };

        // Render Winners List Container
        const startY = 490;
        const maxVisibleWinners = totalWinners <= 3 ? totalWinners : totalWinners <= 6 ? 6 : 8;

        // If many winners (> 8), calculate auto-scroll offset based on phaseElapsed
        let scrollIndex = 0;
        if (totalWinners > 8) {
          const scrollSpeed = 0.0015;
          scrollIndex = Math.min(
            totalWinners - 8,
            Math.floor(phaseElapsed * scrollSpeed)
          );
        }

        const visibleSlice = winners.slice(scrollIndex, scrollIndex + maxVisibleWinners);

        if (totalWinners === 1) {
          // Single winner card
          const w = winners[0];
          const cardW = 880;
          const cardH = 580;
          const cardX = (CANVAS_WIDTH - cardW) / 2;
          const cardY = startY;

          ctx.save();
          ctx.shadowColor = 'rgba(245, 158, 11, 0.4)';
          ctx.shadowBlur = 35;
          const goldGrad = ctx.createLinearGradient(cardX, cardY, cardX + cardW, cardY + cardH);
          goldGrad.addColorStop(0, 'rgba(245, 158, 11, 0.2)');
          goldGrad.addColorStop(0.5, 'rgba(126, 58, 242, 0.25)');
          goldGrad.addColorStop(1, 'rgba(236, 72, 153, 0.2)');
          ctx.fillStyle = goldGrad;
          roundRect(ctx, cardX, cardY, cardW, cardH, 36);
          ctx.fill();

          ctx.shadowBlur = 0;
          ctx.strokeStyle = '#F59E0B';
          ctx.lineWidth = 4;
          ctx.stroke();

          // Badge: Ganador 1
          ctx.fillStyle = '#F59E0B';
          roundRect(ctx, CANVAS_WIDTH / 2 - 140, cardY - 24, 280, 48, 24);
          ctx.fill();
          ctx.fillStyle = '#0B0F19';
          ctx.font = '800 24px "Plus Jakarta Sans", sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText('GANADOR 1', CANVAS_WIDTH / 2, cardY + 8);

          // Winner Avatar
          const wAvatarSize = 160;
          const wAvatarY = cardY + 140;
          ctx.beginPath();
          ctx.arc(CANVAS_WIDTH / 2, wAvatarY, wAvatarSize / 2, 0, Math.PI * 2);
          ctx.fillStyle = '#F59E0B';
          ctx.fill();
          ctx.strokeStyle = '#FFFFFF';
          ctx.lineWidth = 6;
          ctx.stroke();

          ctx.fillStyle = '#0B0F19';
          ctx.font = '800 68px "Plus Jakarta Sans", sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText((w?.username || '1')[0].toUpperCase(), CANVAS_WIDTH / 2, wAvatarY);

          // Winner username
          ctx.fillStyle = '#FFFFFF';
          ctx.font = '800 56px "Plus Jakarta Sans", sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'alphabetic';
          ctx.fillText(formatName(w?.username), CANVAS_WIDTH / 2, cardY + 290);

          // Winner comment
          ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
          ctx.font = 'italic 500 30px "Plus Jakarta Sans", sans-serif';
          const winComment = w?.comment || '¡Participando!';
          const wrappedComment = winComment.length > 60 ? winComment.substring(0, 58) + '...' : winComment;
          ctx.fillText(`“${wrappedComment}”`, CANVAS_WIDTH / 2, cardY + 360);

          // Verified Winner Badge
          ctx.fillStyle = '#10B981';
          roundRect(ctx, CANVAS_WIDTH / 2 - 160, cardY + 440, 320, 56, 28);
          ctx.fill();
          ctx.fillStyle = '#FFFFFF';
          ctx.font = '700 24px "Plus Jakarta Sans", sans-serif';
          ctx.fillText('✓ GANADOR OFICIAL', CANVAS_WIDTH / 2, cardY + 476);
          ctx.restore();
        } else {
          // Multiple equal winners: Ganador 1, Ganador 2...
          const rowHeight = totalWinners <= 4 ? 130 : totalWinners <= 6 ? 100 : 85;
          const listWidth = 920;
          const listX = (CANVAS_WIDTH - listWidth) / 2;

          visibleSlice.forEach((w, localIdx) => {
            const globalIndex = scrollIndex + localIdx + 1;
            const rowY = startY + localIdx * (rowHeight + 14);

            ctx.save();
            ctx.fillStyle = 'rgba(255, 255, 255, 0.06)';
            ctx.strokeStyle = 'rgba(245, 158, 11, 0.4)';
            ctx.lineWidth = 2.5;
            roundRect(ctx, listX, rowY, listWidth, rowHeight, 22);
            ctx.fill();
            ctx.stroke();

            // Number badge: "Ganador 1", "Ganador 2"...
            const badgeW = 160;
            ctx.fillStyle = '#F59E0B';
            roundRect(ctx, listX + 16, rowY + (rowHeight - 44) / 2, badgeW, 44, 14);
            ctx.fill();
            ctx.fillStyle = '#0B0F19';
            ctx.font = '800 20px "Plus Jakarta Sans", sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(`Ganador ${globalIndex}`, listX + 16 + badgeW / 2, rowY + rowHeight / 2 + 7);

            // Winner Name / Handle
            ctx.fillStyle = '#FFFFFF';
            ctx.font = '800 32px "Plus Jakarta Sans", sans-serif';
            ctx.textAlign = 'left';
            const nameStr = formatName(w.username);
            const truncName = nameStr.length > 24 ? nameStr.substring(0, 22) + '...' : nameStr;
            ctx.fillText(truncName, listX + badgeW + 36, rowY + rowHeight / 2 + 10);

            // Check icon
            ctx.fillStyle = '#10B981';
            ctx.font = '700 26px "Plus Jakarta Sans", sans-serif';
            ctx.textAlign = 'right';
            ctx.fillText('✓', listX + listWidth - 24, rowY + rowHeight / 2 + 8);

            ctx.restore();
          });

          // If there are more winners not currently visible
          if (totalWinners > maxVisibleWinners) {
            ctx.save();
            ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
            ctx.font = '600 22px "Plus Jakarta Sans", sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(`Mostrando ${scrollIndex + 1} a ${scrollIndex + visibleSlice.length} de ${totalWinners} ganadores`, CANVAS_WIDTH / 2, startY + visibleSlice.length * (rowHeight + 14) + 30);
            ctx.restore();
          }
        }

        // Substitutes section if exists
        if (substitutes.length > 0) {
          const subStartY = totalWinners === 1 ? 1220 : 1380;
          ctx.save();
          ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
          ctx.font = '700 26px "Plus Jakarta Sans", sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText(`Suplentes de Reserva (${substitutes.length})`, CANVAS_WIDTH / 2, subStartY);

          substitutes.slice(0, 2).forEach((s, idx) => {
            const sY = subStartY + 35 + idx * 75;
            ctx.fillStyle = 'rgba(255, 255, 255, 0.04)';
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
            ctx.lineWidth = 1.5;
            roundRect(ctx, CANVAS_WIDTH / 2 - 380, sY, 760, 64, 16);
            ctx.fill();
            ctx.stroke();

            ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
            ctx.font = '600 24px "Plus Jakarta Sans", sans-serif';
            ctx.textAlign = 'left';
            ctx.fillText(`Suplente ${idx + 1}: ${formatName(s.username)}`, CANVAS_WIDTH / 2 - 340, sY + 40);
          });
          ctx.restore();
        }

        // Safe Area Footer: Audit info & Certificate QR/Code (Bottom 250px)
        ctx.save();
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(CANVAS_WIDTH / 2 - 240, 1680);
        ctx.lineTo(CANVAS_WIDTH / 2 + 240, 1680);
        ctx.stroke();

        ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
        ctx.font = '500 22px "JetBrains Mono", monospace';
        ctx.textAlign = 'center';
        ctx.fillText(`Certificado: ${audit.verificationCode}`, CANVAS_WIDTH / 2, 1720);

        ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
        ctx.font = '400 20px "Plus Jakarta Sans", sans-serif';
        const formattedDate = new Date(audit.drawnAt).toLocaleString('es-ES', {
          dateStyle: 'medium',
          timeStyle: 'short',
        });
        ctx.fillText(`Verificado en sorteoo.app · ${formattedDate}`, CANVAS_WIDTH / 2, 1760);
        ctx.restore();

        // Celebration phase transition
        if (currentPhase === 'revealing' && phaseElapsed > 1500) {
          currentPhase = 'celebrating';
          phaseStartTime = now;
          setPhase('celebrating');
          setStatusMessage('Finalizando grabación del sorteo...');
          createConfettiBurst(80, 500);
        }

        // Hold celebration for 4 seconds so the recorded video captures the full celebration
        if (currentPhase === 'celebrating' && phaseElapsed > 4500) {
          currentPhase = 'done';
          setPhase('finalizing');
          setStatusMessage('Completando y procesando archivo de video...');

          // Stop recorder
          if (recorder && recorder.state === 'recording') {
            recorder.onstop = () => {
              const videoBlob = new Blob(chunksRef.current, {
                type: selectedMimeType || 'video/webm',
              });

              // Create data URL
              const reader = new FileReader();
              reader.readAsDataURL(videoBlob);
              reader.onloadend = () => {
                const dataUrl = reader.result as string;
                onFinish({
                  videoBlob,
                  videoDataUrl: dataUrl,
                  durationSeconds: Math.round(elapsed / 1000),
                  mimeType: selectedMimeType || 'video/webm',
                  recordingError: recordingError || undefined,
                });
              };
            };
            recorder.stop();
          } else {
            // No recorder fallback
            onFinish({
              videoBlob: null,
              videoDataUrl: null,
              durationSeconds: Math.round(elapsed / 1000),
              mimeType: 'none',
              recordingError: recordingError || 'Grabación no soportada en este entorno',
            });
          }
          return;
        }
      }

      // Draw confetti particles
      for (let i = confetti.length - 1; i >= 0; i--) {
        const p = confetti[i];
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.35; // gravity
        p.rotation += p.vRot;

        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rotation);
        ctx.fillStyle = p.color;

        if (p.shape === 'rect') {
          ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.6);
        } else {
          ctx.beginPath();
          ctx.arc(0, 0, p.size / 2, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();

        // Remove off-screen particles
        if (p.y > CANVAS_HEIGHT + 50) {
          confetti.splice(i, 1);
        }
      }

      // Request next frame
      if (currentPhase !== 'done') {
        animationFrameRef.current = requestAnimationFrame(render);
      }
    };

    animationFrameRef.current = requestAnimationFrame(render);

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      if (recorder && recorder.state === 'recording') {
        try {
          recorder.stop();
        } catch (e) {
          // ignore
        }
      }
    };
  }, []);

  // Helper for drawing rounded rect on Canvas
  function roundRect(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    width: number,
    height: number,
    radius: number
  ) {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    ctx.lineTo(x + width, y + height - radius);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    ctx.lineTo(x + radius, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-[85vh] py-8 px-4">
      {/* Top indicator bar */}
      <div className="w-full max-w-md mb-4 flex items-center justify-between text-xs text-neutral-400">
        <div className="flex items-center gap-2">
          {recordingActive ? (
            <span className="flex items-center gap-1.5 text-rose-400 font-medium">
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
              GRABANDO AUTOMÁTICAMENTE (9:16)
            </span>
          ) : (
            <span className="text-amber-400 flex items-center gap-1">
              <AlertCircle className="w-3.5 h-3.5" />
              Modo sin grabación
            </span>
          )}
        </div>
        <span className="font-mono tabular-nums text-neutral-400">
          ID: {audit.verificationCode}
        </span>
      </div>

      {/* 9:16 Live Canvas Display */}
      <div className="relative w-full max-w-[380px] aspect-[9/16] bg-neutral-950 rounded-2xl overflow-hidden shadow-2xl border border-neutral-800 flex items-center justify-center">
        <canvas
          ref={canvasRef}
          className="w-full h-full object-cover block"
        />

        {/* Floating status pill for the user */}
        <div className="absolute bottom-4 left-4 right-4 bg-black/70 backdrop-blur-md border border-white/10 rounded-xl px-4 py-2.5 text-center pointer-events-none">
          <p className="text-xs text-white/90 font-medium">{statusMessage}</p>
        </div>
      </div>

      {/* Stage notes */}
      <div className="mt-4 text-center max-w-sm">
        <p className="text-xs text-neutral-400">
          {phase === 'celebrating' || phase === 'finalizing'
            ? 'Generando y sincronizando el video vertical para Reels y Stories...'
            : 'La animación y el video están sincronizados a 60 FPS en resolución 1080×1920.'}
        </p>
      </div>
    </div>
  );
};
