import React, { useState, useEffect } from 'react';
import { Giveaway } from '../types/giveaway';
import {
  Download,
  Share2,
  Trophy,
  Users,
  CheckCircle,
  Calendar,
  ExternalLink,
  ShieldCheck,
  RotateCcw,
  ListOrdered,
  Instagram,
  Copy,
  Check,
  AlertCircle,
  FileCheck,
  X,
  FileText
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface GiveawayResultsViewProps {
  giveaway: Giveaway;
  videoBlob: Blob | null;
  videoDataUrl: string | null;
  recordingError?: string;
  onNewGiveaway: () => void;
  onGoToHistory: () => void;
}

export const GiveawayResultsView: React.FC<GiveawayResultsViewProps> = ({
  giveaway,
  videoBlob,
  videoDataUrl,
  recordingError,
  onNewGiveaway,
  onGoToHistory,
}) => {
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedCaption, setCopiedCaption] = useState(false);
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [downloadingMp4, setDownloadingMp4] = useState(false);

  useEffect(() => {
    // Launch a celebratory confetti blast on mounting results view
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#FF4B72', '#7E3AF2', '#F59E0B', '#3B82F6', '#10B981'],
      });
    } catch (e) {
      // ignore
    }
  }, []);

  const videoSrc =
    videoDataUrl ||
    (giveaway.video?.hasVideo ? `/api/giveaways/${giveaway.id}/video-stream` : null);

  const formatName = (u: string) => {
    if (!u) return '';
    if (u.startsWith('Número') || u.startsWith('#') || u.includes(' ')) return u;
    return `@${u.replace(/^@/, '')}`;
  };

  // Download real MP4 video file from backend or blob
  const handleDownloadMp4 = async () => {
    setDownloadingMp4(true);
    try {
      // Prefer dedicated MP4 endpoint
      const a = document.createElement('a');
      a.href = `/api/giveaways/${giveaway.id}/download-mp4`;
      a.download = `sorteoo_ganadores_${giveaway.id}.mp4`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch (err) {
      // Fallback to videoStream or Blob
      if (videoBlob) {
        const url = URL.createObjectURL(videoBlob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `sorteoo_ganadores_${giveaway.id}.mp4`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }
    } finally {
      setTimeout(() => setDownloadingMp4(false), 1500);
    }
  };

  // Generate Instagram Post Caption text
  const generateInstagramCaption = () => {
    const winnersList = giveaway.winners
      .map((w, idx) => `Ganador ${idx + 1}: ${formatName(w.username)}`)
      .join('\n');

    let text = `🎉 ¡TENEMOS GANADORES DE NUESTRO SORTEO OFICIAL! 🎉\n\n`;
    text += `Publicación: @${giveaway.postDetails.author}\n\n`;
    text += `🏆 LISTA OFICIAL DE GANADORES:\n${winnersList}\n\n`;

    if (giveaway.substitutes && giveaway.substitutes.length > 0) {
      const subsList = giveaway.substitutes
        .map((s, idx) => `Suplente ${idx + 1}: ${formatName(s.username)}`)
        .join('\n');
      text += `🥈 SUPLENTES DE RESERVA:\n${subsList}\n\n`;
    }

    text += `🔒 Certificado de Transparencia: ${giveaway.audit.verificationCode}\n`;
    text += `Verificado públicamente en https://sorteoo.app/#verify-${giveaway.audit.verificationCode}\n\n`;
    text += `¡Felicidades a los ganadores! Envíanos un mensaje directo para coordinar la entrega de tu premio 🎁✨`;

    return text;
  };

  // Handle Share in Instagram button
  const handleOpenInstagramShare = async () => {
    const shareText = generateInstagramCaption();

    // Check if mobile device supports Web Share API with files or text
    if (navigator.share) {
      try {
        if (videoBlob && navigator.canShare && navigator.canShare({ files: [new File([videoBlob], 'sorteoo.mp4', { type: 'video/mp4' })] })) {
          const file = new File([videoBlob], `sorteoo_sorteo_${giveaway.id}.mp4`, { type: 'video/mp4' });
          await navigator.share({
            title: 'Ganadores Sorteo Instagram - sorteoo.app',
            text: shareText,
            files: [file],
          });
          return;
        } else {
          await navigator.share({
            title: 'Ganadores Sorteo Instagram - sorteoo.app',
            text: shareText,
            url: `${window.location.origin}/#verify-${giveaway.audit.verificationCode}`,
          });
          return;
        }
      } catch (err: any) {
        if (err.name === 'AbortError') return;
      }
    }

    // Open Instagram Share Modal with 1-click tools
    setShareModalOpen(true);
  };

  const copyInstagramCaption = () => {
    const text = generateInstagramCaption();
    navigator.clipboard.writeText(text);
    setCopiedCaption(true);
    setTimeout(() => setCopiedCaption(false), 2000);
  };

  const copyVerificationCode = () => {
    navigator.clipboard.writeText(giveaway.audit.verificationCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const copyVerificationLink = () => {
    const link = `${window.location.origin}/#verify-${giveaway.audit.verificationCode}`;
    navigator.clipboard.writeText(link);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  // Generate PNG Certificate
  const downloadCertificate = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 1200;
    canvas.height = 800;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Dark sleek certificate background
    ctx.fillStyle = '#0B0F19';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Border
    ctx.strokeStyle = '#F59E0B';
    ctx.lineWidth = 6;
    ctx.strokeRect(40, 40, canvas.width - 80, canvas.height - 80);

    // Inner subtle border
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
    ctx.lineWidth = 1;
    ctx.strokeRect(55, 55, canvas.width - 110, canvas.height - 110);

    // Brand
    ctx.fillStyle = '#FFFFFF';
    ctx.font = '800 48px "Plus Jakarta Sans", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('sorteoo.app', canvas.width / 2, 120);

    ctx.fillStyle = '#F59E0B';
    ctx.font = '700 24px "Plus Jakarta Sans", sans-serif';
    ctx.fillText('CERTIFICADO OFICIAL DE VALIDEZ Y TRANSPARENCIA', canvas.width / 2, 165);

    // Post info
    ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
    ctx.font = '500 22px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(
      `Publicación: @${giveaway.postDetails.author} (${giveaway.validParticipantsCount} participantes)`,
      canvas.width / 2,
      220
    );

    // Winners box
    ctx.fillStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.fillRect(150, 260, 900, 250);
    ctx.strokeStyle = '#10B981';
    ctx.lineWidth = 2;
    ctx.strokeRect(150, 260, 900, 250);

    ctx.fillStyle = '#10B981';
    ctx.font = '700 24px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(`LISTA OFICIAL DE GANADORES (${giveaway.winners.length})`, canvas.width / 2, 305);

    giveaway.winners.slice(0, 4).forEach((w, i) => {
      ctx.fillStyle = '#FFFFFF';
      ctx.font = '800 32px "Plus Jakarta Sans", sans-serif';
      ctx.fillText(`Ganador ${i + 1}: ${formatName(w.username)}`, canvas.width / 2, 360 + i * 40);
    });

    if (giveaway.winners.length > 4) {
      ctx.fillStyle = '#F59E0B';
      ctx.font = '600 20px "Plus Jakarta Sans", sans-serif';
      ctx.fillText(`... y ${giveaway.winners.length - 4} ganadores más`, canvas.width / 2, 360 + 4 * 40);
    }

    // Verification Code & SHA-256
    ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
    ctx.font = '600 24px "JetBrains Mono", monospace';
    ctx.fillText(`Código de Validación: ${giveaway.audit.verificationCode}`, canvas.width / 2, 570);

    ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
    ctx.font = '400 16px "JetBrains Mono", monospace';
    ctx.fillText(`Hash SHA-256: ${giveaway.audit.sha256Hash}`, canvas.width / 2, 610);

    const formattedDate = new Date(giveaway.audit.drawnAt).toLocaleString('es-ES', {
      dateStyle: 'full',
      timeStyle: 'medium',
    });
    ctx.fillText(`Fecha y hora de ejecución: ${formattedDate}`, canvas.width / 2, 640);

    ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
    ctx.font = '400 16px "Plus Jakarta Sans", sans-serif';
    ctx.fillText('Verificable públicamente en https://sorteoo.app', canvas.width / 2, 700);

    const a = document.createElement('a');
    a.href = canvas.toDataURL('image/png');
    a.download = `certificado_sorteoo_${giveaway.id}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      {/* Top Banner */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-full text-xs font-semibold mb-3">
          <CheckCircle className="w-4 h-4" />
          Sorteo finalizado con éxito
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
          ¡Lista Oficial de Ganadores!
        </h1>
        <p className="mt-2 text-sm text-neutral-400 max-w-xl mx-auto">
          Proceso aleatorio completado con {giveaway.winners.length} ganador{giveaway.winners.length > 1 ? 'es' : ''} con igual validez y video grabado en formato MP4 listo para Reels.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Equal Winners List & Substitutes (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Main Winners Card: Full list like Sortealo */}
          <div className="bg-neutral-900 border border-amber-500/30 rounded-2xl p-6 relative overflow-hidden shadow-xl">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                  <Trophy className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-white">
                    Ganadores Oficiales ({giveaway.winners.length})
                  </h2>
                  <p className="text-xs text-neutral-400">
                    Todos los ganadores tienen igual categoría y validez
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={copyInstagramCaption}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold rounded-lg transition-colors"
              >
                {copiedCaption ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedCaption ? 'Copiado' : 'Copiar lista'}</span>
              </button>
            </div>

            {/* List of ALL winners: Ganador 1, Ganador 2, ... */}
            <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
              {giveaway.winners.map((winner, index) => (
                <div
                  key={index}
                  className="bg-neutral-950/80 border border-neutral-800 hover:border-neutral-700 rounded-xl p-3.5 flex items-center justify-between gap-3 transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <span className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 font-extrabold text-xs flex items-center justify-center shrink-0">
                      #{index + 1}
                    </span>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-white truncate">
                          {formatName(winner.username)}
                        </span>
                        <span className="text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-1.5 py-0.5 rounded">
                          Ganador {index + 1}
                        </span>
                      </div>
                      <p className="text-xs text-neutral-400 italic truncate mt-0.5">
                        “{winner.comment}”
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Substitutes / Suplentes */}
          {giveaway.substitutes && giveaway.substitutes.length > 0 && (
            <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 shadow-sm">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 rounded-lg bg-neutral-800 text-neutral-300 flex items-center justify-center">
                  <ListOrdered className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">
                    Suplentes de Reserva ({giveaway.substitutes.length})
                  </h3>
                  <p className="text-xs text-neutral-400">
                    En orden de prioridad oficial si algún ganador no cumple los requisitos
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {giveaway.substitutes.map((sub, idx) => (
                  <div
                    key={idx}
                    className="bg-neutral-950/60 border border-neutral-800 rounded-lg p-3 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-white">{formatName(sub.username)}</span>
                      <span className="text-[10px] text-indigo-400 font-semibold bg-indigo-500/10 px-2 py-0.5 rounded">
                        Suplente {idx + 1}
                      </span>
                    </div>
                    <p className="text-[11px] text-neutral-400 truncate mt-1">“{sub.comment}”</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Giveaway Details & Verificador Info */}
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Certificado del Verificador de Transparencia</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="bg-neutral-950 p-3 rounded-xl border border-neutral-800/80">
                <span className="text-neutral-400 block mb-1">Código del Verificador</span>
                <div className="flex items-center justify-between">
                  <span className="font-mono font-semibold text-white">
                    {giveaway.audit.verificationCode}
                  </span>
                  <button
                    onClick={copyVerificationCode}
                    className="p-1 hover:text-white text-neutral-400 transition-colors"
                    title="Copiar código del verificador"
                  >
                    {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div className="bg-neutral-950 p-3 rounded-xl border border-neutral-800/80">
                <span className="text-neutral-400 block mb-1">Participantes válidos</span>
                <span className="font-semibold text-white tabular-nums">
                  {giveaway.validParticipantsCount} de {giveaway.totalParticipantsDetected}
                </span>
              </div>
            </div>

            <div className="flex flex-wrap gap-3 pt-2">
              <button
                onClick={downloadCertificate}
                className="inline-flex items-center gap-1.5 px-3 py-2 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-medium rounded-lg transition-colors"
              >
                <FileCheck className="w-3.5 h-3.5 text-emerald-400" />
                Descargar Certificado (PNG)
              </button>

              <button
                onClick={copyVerificationLink}
                className="inline-flex items-center gap-1.5 px-3 py-2 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-medium rounded-lg transition-colors"
              >
                {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedLink ? 'Enlace copiado' : 'Copiar enlace del Verificador'}
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Video Preview & Export Actions (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6">
            <h3 className="text-sm font-bold text-white mb-2 flex items-center justify-between">
              <span>Video Grabado (9:16)</span>
              <span className="text-[11px] font-bold text-rose-400 bg-rose-500/10 px-2.5 py-0.5 rounded-full border border-rose-500/20">
                Formato MP4
              </span>
            </h3>
            <p className="text-xs text-neutral-400 mb-4">
              Grabación en alta definición vertical optimizada para Reels y Stories.
            </p>

            {/* Video Player */}
            {videoSrc ? (
              <div className="relative mx-auto w-full max-w-[280px] aspect-[9/16] bg-black rounded-xl overflow-hidden shadow-2xl border border-neutral-800">
                <video
                  src={videoSrc}
                  controls
                  playsInline
                  className="w-full h-full object-cover"
                />
              </div>
            ) : (
              <div className="relative mx-auto w-full max-w-[280px] aspect-[9/16] bg-neutral-950 rounded-xl border border-neutral-800 flex flex-col items-center justify-center p-6 text-center">
                <AlertCircle className="w-10 h-10 text-amber-400 mb-2" />
                <p className="text-xs text-neutral-300 font-medium">Video no disponible</p>
                <p className="text-[11px] text-neutral-500 mt-1">
                  {recordingError || 'El entorno del navegador no generó el archivo de video.'}
                </p>
              </div>
            )}

            {/* Action Buttons: MP4 Download and Instagram Share */}
            <div className="space-y-3 mt-6">
              <button
                onClick={handleDownloadMp4}
                disabled={downloadingMp4}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-rose-500 via-pink-500 to-indigo-600 hover:from-rose-600 hover:to-indigo-700 disabled:opacity-50 text-white text-sm font-bold rounded-xl shadow-lg transition-all transform active:scale-[0.98]"
              >
                <Download className="w-4 h-4" />
                <span>{downloadingMp4 ? 'Descargando MP4...' : 'Descargar Video (MP4)'}</span>
              </button>

              <button
                onClick={handleOpenInstagramShare}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-fuchsia-600 via-rose-600 to-amber-500 hover:opacity-95 text-white text-sm font-bold rounded-xl shadow-md transition-all"
              >
                <Instagram className="w-4 h-4" />
                <span>Compartir en Instagram</span>
              </button>
            </div>
          </div>

          {/* Navigation CTAs */}
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-4 flex flex-col gap-2">
            <button
              onClick={onNewGiveaway}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold rounded-xl transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Crear Nuevo Sorteo
            </button>
            <button
              onClick={onGoToHistory}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-transparent hover:bg-neutral-800/50 text-neutral-400 hover:text-white text-xs font-medium rounded-xl transition-colors"
            >
              <Users className="w-3.5 h-3.5" />
              Ver en Mis Sorteos
            </button>
          </div>
        </div>
      </div>

      {/* Dedicated Instagram Sharing Modal */}
      {shareModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="relative w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-2xl p-6 sm:p-8 shadow-2xl space-y-6">
            <button
              onClick={() => setShareModalOpen(false)}
              className="absolute top-4 right-4 p-1.5 text-neutral-400 hover:text-white rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 via-rose-500 to-fuchsia-600 flex items-center justify-center text-white shadow-lg">
                <Instagram className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Compartir en Instagram</h3>
                <p className="text-xs text-neutral-400">
                  Publica los ganadores y el video en tus Stories o Reels
                </p>
              </div>
            </div>

            {/* Step-by-step guidance */}
            <div className="space-y-4 text-xs">
              <div className="p-4 bg-neutral-950 rounded-xl border border-neutral-800 space-y-2">
                <span className="font-semibold text-rose-400 block">
                  Paso 1: Copiar el texto oficial de los ganadores
                </span>
                <p className="text-neutral-400">
                  Hemos redactado el pie de foto con los {giveaway.winners.length} ganadores, el código de validación y el enlace de transparencia:
                </p>
                <button
                  type="button"
                  onClick={copyInstagramCaption}
                  className="w-full flex items-center justify-center gap-2 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded-lg font-semibold transition-colors mt-2"
                >
                  {copiedCaption ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-rose-400" />}
                  <span>{copiedCaption ? '¡Texto copiado al portapapeles!' : 'Copiar texto para la publicación'}</span>
                </button>
              </div>

              <div className="p-4 bg-neutral-950 rounded-xl border border-neutral-800 space-y-2">
                <span className="font-semibold text-amber-400 block">
                  Paso 2: Descargar el video vertical (MP4)
                </span>
                <p className="text-neutral-400">
                  El video en formato 9:16 está preparado con márgenes seguros para Stories y Reels:
                </p>
                <button
                  type="button"
                  onClick={handleDownloadMp4}
                  className="w-full flex items-center justify-center gap-2 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded-lg font-semibold transition-colors mt-2"
                >
                  <Download className="w-4 h-4 text-amber-400" />
                  <span>Descargar archivo MP4</span>
                </button>
              </div>

              <div className="p-4 bg-neutral-950 rounded-xl border border-neutral-800 space-y-2">
                <span className="font-semibold text-indigo-400 block">
                  Paso 3: Abrir Instagram
                </span>
                <p className="text-neutral-400">
                  Crea una nueva Historia o Reel, adjunta el video descargado y pega el texto de los ganadores:
                </p>
                <a
                  href="https://www.instagram.com/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full flex items-center justify-center gap-2 py-2.5 bg-gradient-to-r from-rose-500 to-indigo-600 hover:from-rose-600 hover:to-indigo-700 text-white rounded-lg font-bold transition-all mt-2"
                >
                  <Instagram className="w-4 h-4" />
                  <span>Abrir Instagram Web / App</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
